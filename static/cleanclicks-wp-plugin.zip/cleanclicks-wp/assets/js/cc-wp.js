/**
 * cc-wp.js — CleanClicks WordPress client-side tracking companion.
 *
 * Capabilities:
 *   - Self-contained click ID capture + persistence (cookie/localStorage)
 *   - SHA-256 email hashing with Google-standard normalization
 *   - Direct /__cc/conv posting (works even if cc.js fails to load)
 *   - Direct /__cc/identify posting for email ↔ click ID mapping
 *   - Client-side deduplication (hourly hash)
 *   - Session tracking (session_id, session_number)
 *   - Full page context on every event (GA4 parity)
 *   - WooCommerce ecommerce event consumption (from PHP-injected __ccwpQueue)
 *   - GA4 dataLayer pushes for real-time reporting
 *   - Usermaven session stitching (anonymous_id from cookie → server-side dispatch)
 *   - Consent-aware: respects GPC, opt-out cookie, WP Consent API (category + service-level)
 *   - OneTrust → WP Consent API bridge (OneTrust isn't WP-Consent-API integrated by default)
 *   - Independent of cc.js (no ccRelay coupling)
 *
 * Version: 1.6.0
 */
(function () {
  "use strict";

  var cfg = window.__ccwp || {};
  var ORIGIN = cfg.origin || "";
  var DOMAIN = cfg.domain || "";
  var DEBUG = !!cfg.debug;
  var SOURCE = cfg.source || "wordpress_plugin";
  var DATALAYER_PUSH = cfg.dataLayerPush !== false;
  var CAPTURE_PARAMS = cfg.captureQueryParams || [
    "gclid","wbraid","gbraid","fbclid","ttclid","tbclid","li_fat_id","msclkid"
  ];
  var ATTRIB_PARAMS = ["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"];
  var DEDUPE_WINDOW = (cfg.dedupeWindowSeconds || 86400) * 1000;
  var CURRENCY = cfg.currency || "USD";
  var GA4_MEASUREMENT_ID = cfg.ga4MeasurementId || "";

  // Storage keys.
  var SK_CLICK_IDS = "cc_click_ids";
  var SK_EMAIL     = "cc_wp_hashed_email";
  var SK_ATTRIB    = "cc_attribution";
  var SK_SESSION   = "cc_session_id";
  var SK_SESSNUM   = "cc_session_num";
  var SK_DEDUPE    = "cc_wp_deduped";

  /* ── Logging ─────────────────────────────────────────────────────────── */
  function log() {
    if (DEBUG) console.log.apply(console, ["[CleanClicks-WP]"].concat(Array.prototype.slice.call(arguments)));
  }

  /* ── Consent / Opt-Out ───────────────────────────────────────────────── */
  function isOptedOut() {
    // GPC signal.
    if (navigator.globalPrivacyControl) return true;
    // CleanClicks opt-out cookie.
    if (document.cookie.indexOf("cc_ss_optout=1") !== -1) return true;
    return false;
  }

  function hasConsent() {
    if (!cfg.consentRequired) return true;
    // D2-NEW-4: prefer service-level consent (WP Consent API v2.0+) over
    // category-level (v1.x). Lets customers grant/deny "cleanclicks" individually.
    if (typeof window.wp_has_service_consent === "function") {
      return !!window.wp_has_service_consent("cleanclicks");
    }
    // Category-level fallback (v1.x WP Consent API).
    if (typeof window.wp_has_consent === "function") {
      return !!window.wp_has_consent(cfg.consentCategory || "statistics");
    }
    // If consent is required but no consent API found, block by default.
    // This is the safe GDPR-compliant behavior.
    return false;
  }

  /* ── Storage Helpers ─────────────────────────────────────────────────── */
  function ssGet(k) { try { return sessionStorage.getItem(k); } catch(e) { return null; } }
  function ssSet(k, v) { try { sessionStorage.setItem(k, v); } catch(e) {} }
  function lsGet(k) { try { return localStorage.getItem(k); } catch(e) { return null; } }
  function lsSet(k, v) { try { localStorage.setItem(k, v); } catch(e) {} }

  /* ── Click ID Capture ────────────────────────────────────────────────── */
  function captureClickIds() {
    var stored = {};
    try { stored = JSON.parse(ssGet(SK_CLICK_IDS)) || {}; } catch(e) { stored = {}; }

    var params = new URLSearchParams(window.location.search);
    var changed = false;
    for (var i = 0; i < CAPTURE_PARAMS.length; i++) {
      var p = CAPTURE_PARAMS[i];
      var v = params.get(p);
      if (v && stored[p] !== v) {
        stored[p] = v;
        changed = true;
      }
    }
    if (changed) {
      ssSet(SK_CLICK_IDS, JSON.stringify(stored));
      log("Click IDs captured:", stored);
    }
    return stored;
  }

  function getClickIds() {
    try { return JSON.parse(ssGet(SK_CLICK_IDS)) || {}; } catch(e) { return {}; }
  }

  function hasAnyClickId(ids) {
    if (!ids) return false;
    for (var k in ids) {
      if (ids.hasOwnProperty(k) && ids[k]) return true;
    }
    return false;
  }

  /* ── Attribution Capture ─────────────────────────────────────────────── */
  function captureAttribution(isNewSession) {
    var stored = getAttribution();
    var params = new URLSearchParams(window.location.search);
    var changed = false;

    for (var i = 0; i < ATTRIB_PARAMS.length; i++) {
      var p = ATTRIB_PARAMS[i];
      var v = params.get(p);
      if (v && stored[p] !== v) {
        stored[p] = v;
        changed = true;
      }
    }

    // Capture landing page on new sessions only.
    if (isNewSession && !stored.landing_page) {
      stored.landing_page = window.location.pathname + window.location.search;
      changed = true;
    }

    if (changed) {
      lsSet(SK_ATTRIB, JSON.stringify(stored));
      log("Attribution captured:", stored);
    }
    return stored;
  }

  /* ── GA4 Client ID ──────────────────────────────────────────────────── */
  function getGA4ClientId() {
    var match = document.cookie.match(/(?:^|;\s*)_ga=([^;]+)/);
    if (!match) return "";
    // _ga format: GA1.1.XXXXXXXXXX.XXXXXXXXXX — client_id is last two segments
    var parts = match[1].split(".");
    return parts.length >= 4 ? parts.slice(2).join(".") : "";
  }

  /* ── Usermaven Anonymous ID ──────────────────────────────────────────── */
  function getUsermavenAnonId() {
    var c = document.cookie.split(";");
    for (var i = 0; i < c.length; i++) {
      var s = c[i].trim();
      if (s.indexOf("__eventn_id") === 0 || s.indexOf("_eventn_id") === 0 || s.indexOf("usermaven_id") === 0) {
        if (s.indexOf("_usr") > 0) continue;
        var eq = s.indexOf("=");
        if (eq > 0) return s.substring(eq + 1);
      }
    }
    return "";
  }

  /* ── Session Tracking ────────────────────────────────────────────────── */
  function initSession() {
    var sid = ssGet(SK_SESSION);
    var isNew = false;
    if (!sid) {
      sid = String(Date.now());
      ssSet(SK_SESSION, sid);
      isNew = true;
      // Increment session number.
      var num = parseInt(lsGet(SK_SESSNUM), 10) || 0;
      num++;
      lsSet(SK_SESSNUM, String(num));
      log("New session:", sid, "number:", num);
    }
    return { id: sid, isNew: isNew };
  }

  function getSessionId() {
    return ssGet(SK_SESSION) || initSession().id;
  }

  function getSessionNumber() {
    return parseInt(lsGet(SK_SESSNUM), 10) || 1;
  }

  /* ── Attribution ─────────────────────────────────────────────────────── */
  function getAttribution() {
    try { return JSON.parse(lsGet(SK_ATTRIB)) || {}; } catch(e) { return {}; }
  }

  /* ── SHA-256 Hashing ─────────────────────────────────────────────────── */
  function sha256Hex(str) {
    var enc = new TextEncoder().encode(str);
    return crypto.subtle.digest("SHA-256", enc).then(function (buf) {
      return Array.from(new Uint8Array(buf)).map(function (b) {
        return b.toString(16).padStart(2, "0");
      }).join("");
    });
  }

  /** Google-required email normalization. */
  function normalizeEmail(email) {
    var e = String(email || "").trim().toLowerCase();
    var at = e.lastIndexOf("@");
    if (at <= 0) return "";
    var local = e.slice(0, at).trim();
    var domain = e.slice(at + 1).trim();
    if (!local || !domain) return "";
    if (domain === "googlemail.com") domain = "gmail.com";
    if (domain === "gmail.com") {
      var plus = local.indexOf("+");
      if (plus >= 0) local = local.slice(0, plus);
      local = local.replace(/\./g, "");
    }
    return local + "@" + domain;
  }

  function hashEmail(email) {
    var norm = normalizeEmail(email);
    if (!norm) return Promise.resolve("");
    return sha256Hex(norm);
  }

  function getStoredHashedEmail() {
    var h = lsGet(SK_EMAIL);
    return (h && /^[a-f0-9]{64}$/.test(h)) ? h : "";
  }

  function storeHashedEmail(hex) {
    if (/^[a-f0-9]{64}$/.test(hex)) lsSet(SK_EMAIL, hex);
  }

  /* ── Deduplication ───────────────────────────────────────────────────── */
  function dedupeKey(eventName, orderid) {
    var hour = Math.floor(Date.now() / 3600000);
    return eventName + ":" + DOMAIN + ":" + hour + ":" + (orderid || window.location.pathname);
  }

  function isDuplicate(key) {
    try {
      var store = JSON.parse(lsGet(SK_DEDUPE)) || {};
      var now = Date.now();
      // Prune expired entries.
      var pruned = {};
      for (var k in store) {
        if (store.hasOwnProperty(k) && store[k] > now) pruned[k] = store[k];
      }
      if (pruned[key]) {
        lsSet(SK_DEDUPE, JSON.stringify(pruned));
        return true;
      }
      pruned[key] = now + DEDUPE_WINDOW;
      lsSet(SK_DEDUPE, JSON.stringify(pruned));
      return false;
    } catch(e) {
      return false;
    }
  }

  /* ── Page Context (GA4 parity) ───────────────────────────────────────── */
  function pageContext() {
    return {
      pageurl:           window.location.href,
      page_title:        (document.title || "").slice(0, 512),
      page_referrer:     (document.referrer || "").slice(0, 2048),
      language:          (navigator.language || "").slice(0, 32),
      screen_resolution: screen.width + "x" + screen.height,
      session_id:        getSessionId(),
      session_number:    getSessionNumber()
    };
  }

  /* ── POST to CleanClicks ─────────────────────────────────────────────── */
  function postConversion(eventName, data, clickIds) {
    if (!ORIGIN || !DOMAIN) return Promise.resolve();

    var dk = dedupeKey(eventName, data.orderid);
    if (isDuplicate(dk)) {
      log("Dedupe skip:", eventName, dk);
      return Promise.resolve();
    }

    var ctx = pageContext();
    var payload = {
      clientdomain: DOMAIN,
      event:        eventName,
      clickids:     clickIds || getClickIds(),
      attribution:  getAttribution(),
      timestamp:    Math.floor(Date.now() / 1000),
      value:        data.value || 0,
      currency:     data.currency || CURRENCY,
      source:       SOURCE
    };

    // Merge page context.
    for (var k in ctx) {
      if (ctx.hasOwnProperty(k)) payload[k] = ctx[k];
    }

    // GA4 session stitching: pass browser's _ga client_id for Measurement Protocol.
    var ga4cid = getGA4ClientId();
    if (ga4cid) payload.ga4_client_id = ga4cid;

    // Usermaven session stitching: pass anonymous_id for server-side dispatch.
    var umaid = getUsermavenAnonId();
    if (umaid) payload.usermaven_anonymous_id = umaid;

    if (data.orderid) payload.orderid = data.orderid;
    if (data.items && data.items.length) payload.items = data.items;
    if (data.tax) payload.tax = data.tax;
    if (data.shipping) payload.shipping = data.shipping;
    if (data.coupon) payload.coupon = data.coupon;

    // Attach hashed email.
    var he = data._hashed_email || getStoredHashedEmail();
    if (he) payload.hashed_email = he;

    // Dedupe ID.
    payload.dedupeid = dk;

    log("→ conv:", eventName, payload);

    return fetch(ORIGIN + "/__cc/conv", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(payload),
      mode: "cors",
      credentials: "include",
      keepalive: true
    }).catch(function (e) {
      log("conv failed:", e);
    });
  }

  function postIdentify(hashedEmail, clickIds) {
    if (!hashedEmail || !ORIGIN || !DOMAIN) return Promise.resolve();
    log("→ identify:", hashedEmail);
    return fetch(ORIGIN + "/__cc/identify", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        clientdomain: DOMAIN,
        hashed_email: hashedEmail,
        clickids:     clickIds || getClickIds(),
        attribution:  getAttribution(),
        ga4_client_id: getGA4ClientId(),
        usermaven_anonymous_id: getUsermavenAnonId()
      }),
      mode: "cors",
      credentials: "include",
      keepalive: true
    }).catch(function () {});
  }

  /* ── GA4 dataLayer Push ──────────────────────────────────────────────── */
  function pushDataLayer(eventName, data) {
    if (!DATALAYER_PUSH) return;

    // Clear previous ecommerce data to prevent bleed (in isolated data layer).
    if (typeof window.ccGtag === "function") {
      window.ccDataLayer = window.ccDataLayer || [];
      window.ccDataLayer.push({ ecommerce: null });
    } else {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({ ecommerce: null });
    }

    var ecom = {
      currency: data.currency || CURRENCY,
      value:    data.value || 0
    };
    if (data.items) ecom.items = data.items;
    if (data.orderid) ecom.transaction_id = data.orderid;
    if (data.tax) ecom.tax = data.tax;
    if (data.shipping) ecom.shipping = data.shipping;
    if (data.coupon) ecom.coupon = data.coupon;
    if (data.item_list_name) ecom.item_list_name = data.item_list_name;

    // Use CleanClicks' isolated ccGtag function (pushes to ccDataLayer, not
    // the shared window.dataLayer). This guarantees events only reach the
    // CleanClicks GA4 property, regardless of other GTM/GA4 tags on the page.
    if (GA4_MEASUREMENT_ID && typeof window.ccGtag === "function") {
      var params = {};
      for (var k in ecom) {
        if (ecom.hasOwnProperty(k)) params[k] = ecom[k];
      }
      params.send_to = GA4_MEASUREMENT_ID;
      window.ccGtag("event", eventName, params);
    } else if (GA4_MEASUREMENT_ID && typeof window.gtag === "function") {
      // Legacy fallback: if ccGtag not available (proxy not loaded), use gtag
      // with send_to to at least scope to the correct measurement ID.
      var params2 = {};
      for (var k2 in ecom) {
        if (ecom.hasOwnProperty(k2)) params2[k2] = ecom[k2];
      }
      params2.send_to = GA4_MEASUREMENT_ID;
      window.gtag("event", eventName, params2);
    }

    log("→ dataLayer:", eventName, ecom);
  }

  /* ── Process Event Queue ─────────────────────────────────────────────── */
  // Per v2 D2(a): functional events fire regardless of consent state; analytics
  // events are gated and re-queued for drain on consent grant.
  function processQueue() {
    if (!ORIGIN || !DOMAIN) {
      log("No origin/domain, skipping queue");
      return;
    }

    var queue = window.__ccwpQueue || [];
    if (!queue.length) return;

    // Snapshot and clear.
    var events = queue.slice();
    window.__ccwpQueue = [];
    var deferred = [];

    var clickIds = getClickIds();
    var consentForAnalytics = !cfg.consentRequired || hasConsent();

    for (var i = 0; i < events.length; i++) {
      var ev = events[i];
      var name = ev.name || "";
      var payload = ev.payload || {};
      if (!name) continue;

      log("Processing:", name, payload);

      // D2-NEW-3: pre_purchase_identify is functional capture — fires even
      // under consent reject. cpath-proxy /__cc/identify is opt-out-aware
      // (skips forward mapping, marks reverse opted_out:true). Required to
      // populate CC_IDENT BEFORE the WC order.created webhook delivers, since
      // watchForms doesn't fire on Blocks checkouts (see F-04 + F-11).
      if (name === "pre_purchase_identify") {
        var preEmail = payload._hashed_email || "";
        if (preEmail && hasAnyClickId(clickIds)) {
          postIdentify(preEmail, clickIds);
        }
        continue;
      }

      // Below this line: analytics events. Gate on consent; defer if not granted.
      if (!consentForAnalytics) {
        deferred.push(ev);
        continue;
      }

      // Handle purchase email — prefer server-side pre-hashed, fallback to client-side hashing.
      if (name === "purchase" && (payload._hashed_email || payload.billing_email)) {
        (function (n, p, ids) {
          var doPost = function (hashed) {
            if (hashed) {
              storeHashedEmail(hashed);
              p._hashed_email = hashed;
              if (hasAnyClickId(ids)) {
                postIdentify(hashed, ids);
              }
            }
            delete p.billing_email;
            postConversion(n, p, ids);
            pushDataLayer(n, p);
          };
          if (p._hashed_email && !p.billing_email) {
            // Already hashed server-side (L12 fix).
            doPost(p._hashed_email);
          } else {
            hashEmail(p.billing_email).then(doPost);
          }
        })(name, payload, clickIds);
        continue;
      }

      // All other analytics events.
      postConversion(name, payload, clickIds);
      pushDataLayer(name, payload);
    }

    // Re-queue analytics events that need consent. A later consent-grant pass
    // (wp_listen_for_consent_change / cookieyes_consent_update / cmplz_fire_categories)
    // re-calls processQueue and drains them.
    if (deferred.length) {
      window.__ccwpQueue = (window.__ccwpQueue || []).concat(deferred);
    }
  }

  // Expose for dynamic add-to-cart events.
  window.__ccwpProcessQueue = processQueue;

  /* ── Email Identification on Forms ───────────────────────────────────── */
  function watchForms() {
    document.addEventListener("submit", function (e) {
      var form = e.target;
      if (!form || form.tagName !== "FORM") return;

      // Find email input.
      var emailInput = form.querySelector('input[type="email"], input[name="email"], input[name="billing_email"], input[name*="email"]');
      if (!emailInput || !emailInput.value) return;

      var email = emailInput.value.trim();
      if (!email || email.indexOf("@") === -1) return;

      var ids = getClickIds();
      hashEmail(email).then(function (hashed) {
        if (!hashed) return;
        storeHashedEmail(hashed);
        log("Auto-identified email on form submit");
        if (hasAnyClickId(ids)) {
          postIdentify(hashed, ids);
        }
      });
    }, true); // Capture phase so we fire before navigation.
  }

  /* ── Email Input Listener (D2-NEW-3 guest path) ──────────────────────── */
  // Fires postIdentify on debounced email-field input/change. Covers WC Blocks
  // checkouts where watchForms (form-submit) doesn't fire AND guest customers
  // who haven't been resolved by the PHP-side inject_pre_purchase_identify
  // (no cached billing_email yet). Functional capture — runs regardless of
  // consent state. Server-side /__cc/identify is opt-out-aware.
  function watchEmailInputs() {
    var debounceTimer = null;
    var lastHashed = ""; // dedupe identical-hash repeats

    var handler = function (e) {
      var input = e.target;
      if (!input || input.tagName !== "INPUT") return;
      var isEmailType = input.type === "email";
      if (!isEmailType) {
        var name = (input.getAttribute("name") || "").toLowerCase();
        if (name.indexOf("email") === -1 && name.indexOf("billing_email") === -1) return;
      }
      var email = String(input.value || "").trim();
      // Cheap pre-validation: must have @ in middle and . in domain part.
      var at = email.indexOf("@");
      if (at < 1 || at === email.length - 1) return;
      var dot = email.lastIndexOf(".");
      if (dot < at + 2 || dot === email.length - 1) return;

      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () {
        hashEmail(email).then(function (hashed) {
          if (!hashed || hashed === lastHashed) return;
          lastHashed = hashed;
          storeHashedEmail(hashed);
          var ids = getClickIds();
          if (hasAnyClickId(ids)) {
            log("Pre-submit identify on email input:", hashed);
            postIdentify(hashed, ids);
          }
        });
      }, 800);
    };

    document.addEventListener("input", handler, true); // capture phase
    document.addEventListener("change", handler, true);
    document.addEventListener("blur", handler, true);
  }

  /* ── remove_from_cart (WooCommerce) ──────────────────────────────────── */
  function watchRemoveFromCart() {
    if (typeof jQuery === "undefined") return;
    jQuery(document.body).on("removed_from_cart", function (e, fragments, hash, btn) {
      if (!btn || !btn.length) return;
      var id = btn.data("product_id") || "";
      var name = btn.data("product_name") || "";

      var ev = {
        name: "remove_from_cart",
        payload: {
          currency: CURRENCY,
          value: 0,
          items: id ? [{ item_id: String(id), item_name: String(name), quantity: 1 }] : []
        }
      };
      window.__ccwpQueue = (window.__ccwpQueue || []).concat([ev]);
      processQueue();
    });
  }

  /* ── Checkout Intent Detection (Cart Page) ─────────────────────────── */
  function watchCheckoutIntent() {
    var cartData = window.__ccwpCartData;
    if (!cartData || !cartData.items || !cartData.items.length) return;

    // Already on checkout page? begin_checkout fires from PHP queue. Skip.
    if (document.body && document.body.classList.contains('woocommerce-checkout')) return;

    var fired = false;
    var selectors = '.checkout-button, .wc-proceed-to-checkout a, ' +
                    '.wc-proceed-to-checkout button, [name="checkout"], ' +
                    'a[href*="/checkout"], [class*="checkout-button"]';

    document.addEventListener('click', function (e) {
      if (fired) return;
      var el = e.target;
      // Walk up to find matching element (handles clicks on child elements).
      while (el && el !== document.body) {
        if (el.matches && el.matches(selectors)) {
          fired = true;
          postConversion('begin_checkout', cartData);
          pushDataLayer('begin_checkout', cartData);
          log('begin_checkout fired from cart page checkout intent');
          return;
        }
        el = el.parentElement;
      }
    }, true); // Capture phase — fires before navigation or modal takeover.
  }

  /* ── OneTrust → WP Consent API bridge (D4) ───────────────────────────── */
  // OneTrust isn't WP-Consent-API integrated by default. Without this bridge,
  // OneTrust customers' WP Consent API stays at "deny" for everything — and
  // hasConsent() never flips to true even after the customer accepts. Maps
  // OneTrust's standard category IDs to wp_set_consent() categories:
  //   C0001 → functional (Strictly Necessary)
  //   C0002 → statistics (Performance)
  //   C0004 → marketing  (Targeting / Advertising)
  function bridgeOneTrust() {
    if (typeof window.wp_set_consent !== "function") return;

    var sync = function () {
      var groups = typeof window.OnetrustActiveGroups === "string" ? window.OnetrustActiveGroups : "";
      if (!groups) return;
      var hasC0001 = groups.indexOf(",C0001,") !== -1;
      var hasC0002 = groups.indexOf(",C0002,") !== -1;
      var hasC0004 = groups.indexOf(",C0004,") !== -1;
      try {
        window.wp_set_consent("functional", hasC0001 ? "allow" : "deny");
        window.wp_set_consent("statistics", hasC0002 ? "allow" : "deny");
        window.wp_set_consent("marketing",  hasC0004 ? "allow" : "deny");
      } catch (e) {}
      log("OneTrust → WP Consent API:", { functional: hasC0001, statistics: hasC0002, marketing: hasC0004 });
    };

    // Initial sync — covers the common case of OneTrust loading before us.
    sync();

    // Path A: dataLayer-push interceptor — OneTrust pushes "OneTrustGroupsUpdated" on consent change.
    window.dataLayer = window.dataLayer || [];
    var origPush = window.dataLayer.push.bind(window.dataLayer);
    window.dataLayer.push = function () {
      var ret = origPush.apply(window.dataLayer, arguments);
      for (var i = 0; i < arguments.length; i++) {
        var item = arguments[i];
        if (item && item.event === "OneTrustGroupsUpdated") {
          sync();
          break;
        }
      }
      return ret;
    };

    // Path B: direct OneTrust API listener as backup — fires even if customer's
    // OneTrust deployment doesn't emit OneTrustGroupsUpdated to dataLayer.
    if (typeof window.OneTrust !== "undefined" && typeof window.OneTrust.OnConsentChanged === "function") {
      try { window.OneTrust.OnConsentChanged(sync); } catch (e) {}
    }
  }

  /* ── Initialization ──────────────────────────────────────────────────── */
  function init() {
    if (!ORIGIN || !DOMAIN) {
      log("CleanClicks not configured (missing origin or domain)");
      return;
    }

    // D4: bridge OneTrust → WP Consent API before consent checks fire. Without
    // this, hasConsent() always sees deny on OneTrust sites because OneTrust
    // doesn't natively integrate with the WP Consent API.
    bridgeOneTrust();

    // D2(a): start functional capture immediately (always-on). Click IDs,
    // attribution, session, form-watch, and pre_purchase_identify (queue
    // handler) all fire regardless of consent state. Server-side handlers
    // (/__cc/identify) are opt-out-aware. processQueue() internally gates
    // analytics events on consent and re-queues deferred ones.
    startTracking();

    // D2(a): if analytics consent isn't granted yet, listen for consent flips
    // and re-call processQueue() to drain deferred analytics events (purchase,
    // view_item, view_item_list, begin_checkout, add_to_cart, remove_from_cart).
    if (cfg.consentRequired && !hasConsent()) {
      var onConsent = function () {
        if (hasConsent()) {
          log("Consent granted, draining deferred analytics queue");
          processQueue();
        }
      };
      document.addEventListener("wp_listen_for_consent_change", onConsent);
      document.addEventListener("cookieyes_consent_update", onConsent);
      document.addEventListener("cmplz_fire_categories", onConsent);
    }
  }

  function startTracking() {
    // Signal to cc.js that WP plugin handles ecommerce events.
    window.__ccwpActive = true;

    // Functional capture (always-on, no consent gate). Click IDs are captured
    // regardless of consent or opt-out — they're used for measurement-only
    // server-side correlation and never directly dispatched to vendors when
    // GPC / cc_ss_optout is set.
    captureClickIds();
    var session = initSession();
    captureAttribution(session.isNew);
    watchForms();
    watchEmailInputs();
    watchRemoveFromCart();
    watchCheckoutIntent();

    // GPC / cc_ss_optout cookie — skip the analytics queue drain (event
    // posting suppressed). Functional capture above still ran.
    var optedOut = isOptedOut();
    if (optedOut) {
      log("User opted out (GPC or cookie). Functional capture done; events suppressed.");
      return;
    }

    // processQueue() handles per-event-type consent gating internally:
    //   - pre_purchase_identify (D2-NEW-3): always fires (functional)
    //   - purchase / view_item / etc.: gated on hasConsent(); deferred otherwise
    processQueue();

    log("CleanClicks WordPress v1.6.0 initialized for", DOMAIN);
  }

  // Start when DOM is ready.
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
