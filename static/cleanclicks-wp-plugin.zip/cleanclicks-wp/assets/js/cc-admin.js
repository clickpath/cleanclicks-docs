/**
 * CleanClicks Admin JS — Connection test, config refresh, copy buttons.
 */
(function () {
  "use strict";

  var nonce   = (window.ccAdmin || {}).nonce || "";
  var ajaxUrl = (window.ccAdmin || {}).ajaxUrl || "";

  /* ── Connection Test ─────────────────────────────────────────────────── */
  var testBtn = document.getElementById("cc-test-connection");
  var testResult = document.getElementById("cc-test-result");

  if (testBtn) {
    testBtn.addEventListener("click", function () {
      testBtn.disabled = true;
      testResult.textContent = "Testing...";
      testResult.style.color = "#72777c";

      var fd = new FormData();
      fd.append("action", "cleanclicks_test_connection");
      fd.append("nonce", nonce);

      fetch(ajaxUrl, { method: "POST", body: fd })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          testBtn.disabled = false;
          var statusEl = document.getElementById("cc-conn-status");
          var card = document.getElementById("cc-status-card");
          if (res.success) {
            testResult.innerHTML = '<span style="color:#39894b;">&#10003; cc.js reachable, config loaded</span>';
            if (statusEl) { statusEl.style.color = "#39894b"; statusEl.innerHTML = "&#10003; Connected"; }
            if (card) { card.style.borderLeftColor = "#39894b"; }
          } else {
            var d = res.data || {};
            var parts = [];
            if (d.cc_js === false) parts.push("cc.js unreachable");
            if (d.config === false) parts.push("wp-config endpoint failed");
            testResult.innerHTML = '<span style="color:#d63638;">&#10007; ' + (parts.join(", ") || "Connection failed") + "</span>";
            if (statusEl) { statusEl.style.color = "#d63638"; statusEl.innerHTML = "&#10007; Not connected"; }
            if (card) { card.style.borderLeftColor = "#d63638"; }
          }
        })
        .catch(function () {
          testBtn.disabled = false;
          testResult.innerHTML = '<span style="color:#d63638;">&#10007; Network error</span>';
        });
    });
  }

  /* ── Copy Buttons ────────────────────────────────────────────────────── */
  document.querySelectorAll(".cc-copy-btn").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var targetId = btn.getAttribute("data-target");
      var el = document.getElementById(targetId);
      if (!el) return;
      var text = el.textContent || el.innerText;
      navigator.clipboard.writeText(text).then(function () {
        var orig = btn.textContent;
        btn.textContent = "Copied!";
        setTimeout(function () { btn.textContent = orig; }, 1500);
      });
    });
  });

  /* ── A5: Recreate Webhook Button ─────────────────────────────────────── */
  document.querySelectorAll(".cc-recreate-webhook").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var statusEl = btn.parentElement.querySelector(".cc-recreate-status");
      btn.disabled = true;
      if (statusEl) {
        statusEl.innerHTML = '<span style="color:#72777c;">Working&hellip;</span>';
      }

      var fd = new FormData();
      fd.append("action", "cleanclicks_recreate_webhook");
      fd.append("nonce", nonce);

      fetch(ajaxUrl, { method: "POST", body: fd })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          btn.disabled = false;
          if (res.success) {
            var id = res.data && res.data.status && res.data.status.id;
            if (statusEl) {
              statusEl.innerHTML = '<span style="color:#39894b;">&#10003; Webhook ' + (id ? '#' + id : '') + ' active</span>';
            }
            // Reload after 1s so the status card reflects fresh state
            setTimeout(function () { window.location.reload(); }, 1000);
          } else {
            var msg = (res.data && res.data.message) || "Failed";
            if (statusEl) {
              statusEl.innerHTML = '<span style="color:#d63638;">&#10007; ' + msg + '</span>';
            }
          }
        })
        .catch(function () {
          btn.disabled = false;
          if (statusEl) {
            statusEl.innerHTML = '<span style="color:#d63638;">&#10007; Network error</span>';
          }
        });
    });
  });
})();
