=== CleanClicks ===
Contributors: clickpathconsultants
Tags: analytics, conversion tracking, first-party tracking, woocommerce, google ads
Requires at least: 6.0
Tested up to: 6.9
Requires PHP: 7.4
Stable tag: 1.6.1
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

First-party conversion tracking, click ID capture, attribution, and analytics proxy injection for WordPress and WooCommerce.

== Description ==

CleanClicks routes your analytics and conversion tracking through a first-party subdomain on your own domain, bypassing ad blockers and browser privacy restrictions. It captures ad click IDs, tracks the full WooCommerce ecommerce funnel, and sends server-side conversions to Google Ads, Meta, TikTok, LinkedIn, Microsoft Ads, and GA4.

**Requires a CleanClicks account.** This plugin connects your WordPress site to the CleanClicks platform hosted on Cloudflare Workers. Visit [cleanclick.dev](https://cleanclick.dev) for more information.

= Features =

* **Click ID Capture** — Automatically captures gclid, wbraid, gbraid, fbclid, ttclid, tbclid, li_fat_id, and msclkid from URL parameters and persists them in session storage.
* **Email Identity Hashing** — SHA-256 hashes email addresses (Google-standard normalization) from form submissions and WooCommerce checkout for Enhanced Conversions.
* **Direct Conversion Posting** — Posts events directly to the CleanClicks conv endpoint. Works independently of cc.js for maximum reliability.
* **GA4 DataLayer Push** — Pushes GA4-format ecommerce events to the dataLayer for real-time reporting in GA4.
* **Client-Side Deduplication** — Prevents duplicate event firing within configurable time windows.
* **Session Tracking** — Tracks session_id and session_number for GA4-parity analytics.
* **GA4 First-Party Proxy** — Routes GA4 client-side traffic through your first-party domain using server_container_url.
* **Usermaven Proxy** — Injects Usermaven tracking through the CleanClicks first-party proxy.
* **Plerdy Proxy** — Injects Plerdy heatmaps and session recordings through the CleanClicks first-party proxy.
* **WP Consent API Integration** — Respects consent state from compatible consent management plugins (CookieYes, Complianz, etc.).
* **Privacy Compliance** — Supports GPC signals, cookie-based opt-out, GDPR data export/erasure, and CCPA Limited Data Use.

= WooCommerce Ecommerce Tracking =

When WooCommerce is active, the plugin automatically tracks the full ecommerce funnel:

* `view_item` — Single product pages
* `view_item_list` — Shop, category, and tag archive pages (up to 50 items)
* `add_to_cart` — Ajax and form-based add-to-cart actions
* `remove_from_cart` — Cart item removal
* `begin_checkout` — Checkout page load
* `purchase` — Order confirmation with full order data (revenue, tax, shipping, coupon, line items)

All events include enhanced product data: SKU, brand (YITH/taxonomy), up to 5 category levels, and variant information for variable products.

= How It Works =

1. The plugin loads the CleanClicks universal tag (cc.js) from your first-party proxy subdomain.
2. A companion script (cc-wp.js) handles click ID capture, email hashing, and direct endpoint communication.
3. WooCommerce events are captured via PHP hooks and passed to the client-side for processing.
4. Conversion events are posted to CleanClicks, which dispatches them to your configured ad platforms server-side.
5. Analytics proxy scripts (GA4, Usermaven, Plerdy) are injected through the same first-party domain.

= Requirements =

* A CleanClicks account with your domain configured
* A CNAME record: `cleanclicks.yourdomain.com` pointing to `cleanclick.dev`
* PHP 7.4 or higher
* WordPress 6.0 or higher
* WooCommerce 8.0+ (optional, for ecommerce tracking)

== Installation ==

1. Upload the `cleanclicks-wp` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu. The plugin auto-detects your site domain from `home_url()` and fetches its CleanClicks configuration on activation — no manual domain entry required.
3. Navigate to **Settings > CleanClicks** (or **WooCommerce > CleanClicks** if WooCommerce is active).
4. Optionally set an **Origin Override** if your proxy subdomain differs from `https://cleanclicks.<your-domain>`.
5. Enter your **Inbound API Key** (from CleanClicks Integrations tab) if using Usermaven WooCommerce tracking or server-side webhook signing.
6. Click **Test Connection** to verify the CleanClicks proxy is reachable.
7. Enable analytics proxies (GA4, Usermaven, Plerdy) as needed.
8. If using WooCommerce, the plugin auto-creates the conversion-capture webhook on activation. Use the **Webhook Status** card on the settings page to recreate it if needed.

== Frequently Asked Questions ==

= Do I need WooCommerce to use this plugin? =

No. The core features (click ID capture, email hashing, conversion tracking, analytics proxies) work on any WordPress site. WooCommerce ecommerce tracking activates automatically when WooCommerce is detected.

= What is the first-party proxy? =

CleanClicks routes tracking requests through a subdomain on your own domain (e.g., `cleanclicks.yourdomain.com`). This makes the requests first-party, which means ad blockers and browser privacy features like Safari ITP cannot block or restrict them.

= Which consent management plugins are supported? =

The plugin integrates with the WP Consent API, which is supported by CookieYes, Complianz, Cookie Notice, and other compatible plugins. When consent is required, tracking scripts only load after the visitor grants consent.

= Does this plugin replace Google Tag Manager? =

For conversion tracking and analytics proxy injection, yes. CleanClicks handles click ID capture, conversion events, and analytics script loading. You may still use GTM for other marketing tags if desired.

= What data is sent to CleanClicks? =

The plugin sends conversion events (event name, click IDs, hashed email, page context, order data) to your CleanClicks proxy endpoint on your own domain. From there, CleanClicks dispatches to your configured ad platforms server-side. No raw email addresses are transmitted — only SHA-256 hashes.

= Is this GDPR/CCPA compliant? =

The plugin supports GPC (Global Privacy Control) signals, cookie-based opt-out, WP Consent API integration, WordPress privacy data export and erasure hooks, and CCPA Limited Data Use flags for supported ad platforms. You are responsible for implementing a consent management solution appropriate for your jurisdiction.

== Screenshots ==

1. Settings page — Connection and proxy configuration
2. WooCommerce ecommerce tracking in action
3. CleanClicks admin dashboard showing WordPress plugin health status

== Changelog ==

= 1.6.1 — 2026-05-13 =
* NEW: Smart-defaults on fresh install. When the CleanClicks server confirms GA4 First-Party Mode is ready (server-side proxy enabled + measurement ID configured + WordPress plugin mode), the GA4 First-Party Proxy checkbox now auto-enables on fresh plugin installs. Cuts one manual step from the onboarding flow. Server-controlled feature flag (`defaults.smartDefaultsEnabled` in /__cc/wp-config) gates the behavior — ships dormant until the launch-readiness gate flips it on. Preserves customer choice on updates and reactivations; existing installs are never modified. Network failures during the wp-config fetch leave the plugin's defaults all-OFF and activation proceeds cleanly.

= 1.6.0 =
**Phase 8.2c — onboarding polish:**
* NEW: Zero-config setup. The "Client Domain" admin field is gone — domain is auto-detected from `home_url()` (with a leading-`www.` strip for WP Engine and other www-subdomain installs). Pre-1.6.0 installs that already saved a manual override keep their value; new installs need no domain entry.
* NEW: On-activation prefetch of the CleanClicks remote config (`/__cc/wp-config`). Plugin starts with a hydrated 1-hour transient cache instead of waiting for the first front-end request to populate it.
* NEW: Expanded remote config response (schema v2). Top-level `clientDomain`, `ga4Proxy { enabled, measurementId, allowSignals, serverSessionContinuity }`, `vendors` enable map (now includes Usermaven), `proxy` (Plerdy + Usermaven first-party routes), and a `version` field for future schema upgrades. Legacy nested fields (`proxies.ga4`, `tagConfig`, `vendors`) remain populated for backward compatibility.
* NEW: Server-side companion endpoints for button-driven verification: `/api/audit/verify-tag-install` and `/api/audit/verify-cname` — used by the CleanClicks dashboard to give customers structured, actionable failure messages during setup (CNAME wrong target, Cloudflare-proxy detected, propagation in flight, bot blocker active, etc.). No plugin code change required to consume.

**Phase 1.6 v2 — attribution recovery under consent rejection (launch-blocking):**
* FIX: cc-wp.js now sends `credentials: "include"` on `/__cc/conv` and `/__cc/identify` fetches. Previously the cross-origin POST to `cleanclicks.{customer-domain}` defaulted to `same-origin` credentials mode, which prevented the `cc_pid` HttpOnly cookie from traveling on subsequent requests — meaning every cc-wp.js fetch generated a fresh `cc_pid` instead of reusing a stable visitor identifier. Verified empirically against production endpoint 2026-05-06.
* FIX: Cookie classification corrected from `statistics` to `functional` for `cc_pid`, `cc_click_ids`, `cc_attribution`, and `cc_session_id` in `wp_add_cookie_info()`. The previous `statistics` self-classification was telling the 18 WP-Consent-API-integrated CMPs (CookieYes, Cookiebot, Complianz, iubenda, +14 others) to block our cookies under reject — contradicting the architectural design that these are first-party visitor identifiers used for measurement-only correlation. `cc_ss_optout` (privacy opt-out flag) remains correctly classified as `functional`.
* NEW: Consent gate split into Phase 1 (functional, always-on) and Phase 2 (analytics, consent-gated). Click ID capture, attribution capture, session init, form watching, and pre-purchase identify all run regardless of consent state — the cpath-proxy `/__cc/identify` handler is opt-out aware and stores reverse mappings with `opted_out: true` (never used for vendor dispatch under measurement-only mode). Conversion POSTs and dataLayer pushes remain consent-gated. Deferred analytics events are re-queued and drained on consent grant via `wp_listen_for_consent_change`, `cookieyes_consent_update`, and `cmplz_fire_categories` listeners.
* NEW: OneTrust → WP Consent API bridge. OneTrust isn't natively integrated with the WP Consent API, so the plugin now maps `OnetrustActiveGroups` (e.g., `,C0001,C0002,C0004,`) to `wp_set_consent()` automatically. C0001 → functional, C0002 → statistics, C0004 → marketing. Initial sync on page load + dataLayer-push interceptor for `OneTrustGroupsUpdated` events + direct `OneTrust.OnConsentChanged()` API listener as backup. OneTrust customers no longer need to copy custom JavaScript snippets.
* NEW: Pre-webhook identify trigger. Server-renders a `pre_purchase_identify` event with the customer's hashed `billing_email` when the WooCommerce checkout page renders (logged-in customers AND returning guests with cached billing email). Populates `CC_IDENT` BEFORE the `order.created` webhook delivers, so click-ID correlation works even on first-time guest checkouts. Critical for WooCommerce Blocks checkouts where the existing form-submit listener doesn't fire (React + AJAX submission). Hooked at `wp_footer` priority 5 with `is_checkout()` gate. Companion JavaScript debounced input listener handles guest customers who type their email before submitting (800ms debounce on `input`/`change`/`blur` events for fields matching `[type=email]` or `[name*=email]`).
* NEW: WP Consent API integration. Plugin declares itself as a compliant plugin via `add_filter("wp_consent_api_registered_cleanclicks-wp/cleanclicks-wp.php", "__return_true")`. Consent checks now prefer service-level consent (`wp_has_service_consent("cleanclicks")` on WP Consent API v2.0+) over category-level (`wp_has_consent("statistics")` on v1.x), letting customers grant or deny CleanClicks individually within Complianz / CookieYes / iubenda service-toggle UIs without affecting other analytics tools. Function-exists guards keep v1.x backward compatibility. New `cleanclicks_has_consent_for($category)` helper centralizes the preference order.

= 1.5.3 =
* Fixed: cleanclicks_client_domain() now strips leading "www." from the home_url()
  fallback so cleanclicks subdomain origins are derived correctly (e.g.,
  https://cleanclicks.example.com instead of https://cleanclicks.www.example.com).
  Manual Client Domain override is unchanged — user-entered values are sacred.

= 1.5.2 =
* NEW: Auto-creates the WooCommerce webhook on plugin activation and removes it on deactivation. No more manual setup steps.
* NEW: Server-side `woocommerce_payment_complete` hook backstops subscription renewals, custom thank-you flows, and offsite checkout returns. Captures purchases regardless of which page the customer lands on.
* NEW: Configurable Custom Thank-You Paths allowlist for non-standard checkout completion URLs (subscription confirmations, membership signups, custom flows). Optional regex pattern for advanced flows.
* NEW: Admin UI — onboarding banner walks new customers through one-step API-key setup; live webhook status card shows current state with one-click recreate.
* NEW: Filter hooks `cleanclicks_purchase_paths`, `cleanclicks_purchase_path_regex`, and `cleanclicks_resolve_order_id` for programmatic extension.
* DEV: New Playwright test harness in `test/` directory exercises the universal-capture architecture end-to-end against a dedicated WP test environment.

= 1.5.1 =
* Fix: Broadened checkout intent selector to catch third-party checkout buttons (Bolt, Stripe, etc.) that use non-standard markup

= 1.5.0 =
* Self-contained attribution capture: cc-wp.js now captures UTM parameters and landing page independently of cc.js, ensuring ecommerce events always carry campaign context
* Universal begin_checkout: fires on checkout-intent click from the cart page, works with any checkout flow (standard, Bolt, Stripe Checkout, PayPal, etc.)
* Non-AJAX add_to_cart: product data now included in add_to_cart events when WooCommerce redirects to cart instead of using AJAX
* Ecommerce event authority: cc-wp.js signals cc.js to suppress duplicate ecommerce events (view_item, add_to_cart, begin_checkout, etc.) while cc.js continues handling page_view and core tracking
* Cart page data injection: PHP injects current cart contents for client-side checkout detection

= 1.4.3 =
* Fix GA4 Google Signals (demographics/interests): conditionally omit server_container_url from gtag config when Allow Google Signals is enabled in CleanClicks dashboard. server_container_url caused gtag.js to suppress client-side DoubleClick hits, preventing demographic data collection.

= 1.3.8 =
* CRITICAL FIX: WP Rocket compatibility for cc.js and cc-wp.js. WP Rocket was intercepting both scripts — wrapping them in type="rocketlazyloadscript", delaying execution and breaking the trigger engine. Also minified/cached cc.js locally, serving a stale copy instead of the dynamic per-client script.
* cc.js now loads with 'async' strategy (WP Rocket ignores async scripts). cc-wp.js stays on 'defer' but is excluded via rocket_delay_js_exclusions, rocket_exclude_defer_js, and rocket_minify_excluded_external_js filters.
* Moved window.__ccwp config injection from wp_add_inline_script to direct wp_head output (priority 2), ensuring config is always available before cc-wp.js executes regardless of script loading strategy.
* Admin menu: CleanClicks now appears as a top-level menu item (with chart icon) instead of being nested under WooCommerce. Works identically with or without WooCommerce installed — CleanClicks is a standalone product, not a WooCommerce extension.

= 1.3.1 =
* Usermaven session stitching: anonymous_id from Usermaven cookie now included in conversion payloads, enabling server-side ecommerce dispatch to stitch events to client-side browsing sessions
* Removed client-side Usermaven event bridging (pushUsermaven) — ecommerce events now handled server-side via CleanClicks S2S dispatch for accurate WooCommerce dashboard reporting
* Added data-randomize-url attribute to Usermaven SDK script tag for cache-busting URL randomization

= 1.3.0 =
* WP Rocket compatibility: Usermaven and Plerdy proxy scripts now inject directly via wp_head output, bypassing WP Rocket's RocketLazyLoadScripts that delayed execution until user interaction (killing pageview tracking for non-interactive sessions)
* Usermaven WooCommerce event bridge: all 6 ecommerce events (viewed_product, viewed_product_list, added_to_cart, removed_from_cart, initiated_checkout, order_completed) now pushed to the Usermaven SDK with proper property schema mapping, populating Usermaven's WooCommerce analytics dashboards
* Proxy header forwarding: Referer and Origin headers now forwarded on POST requests through proxyTo() for upstream domain attribution
* Customer identification: Usermaven user identity linked on purchase via hashed email for customer-level analytics

= 1.2.0 =
* Fixed duplicate event firing: removed ccRelay.track() fallback that caused every WooCommerce event to fire twice to /__cc/conv when both cc-wp.js and cc.js were loaded on the same page. cc-wp.js is now fully independent of cc.js.
* This affected all vendor dispatches (GA4, Meta, TikTok, LinkedIn, Microsoft Ads), not just GA4.

= 1.1.1 =
* Added GA4 session stitching: cc-wp.js now reads the _ga cookie and passes ga4_client_id through the conv payload for Measurement Protocol session matching
* Added getGA4ClientId() helper for extracting GA4 client_id from the _ga cookie

= 1.0.1 =
* Renamed all PHP constants from generic CC_ prefix to CLEANCLICKS_ prefix to prevent conflicts with other plugins
* Renamed all PHP classes from CC_* to CleanClicks_* to prevent class name collisions
* Renamed plugin folder from cleanclicks-wordpress to cleanclicks-wp
* Updated text domain to cleanclicks-wp
* Tested up to WordPress 6.9

= 1.0.0 =
* Initial release
* Full WordPress plugin with click ID capture, email hashing, session tracking
* Self-contained cc-wp.js client-side tracking (no dependency on cc.js)
* WooCommerce ecommerce funnel: view_item, view_item_list, add_to_cart, remove_from_cart, begin_checkout, purchase
* Enhanced product data: SKU, brand, 5-level categories, variants
* GA4, Usermaven, and Plerdy first-party proxy injection
* WP Consent API integration with CookieYes and Complianz listeners
* Privacy compliance: GPC, data export, data erasure, cookie registration
* Remote config fetching from CleanClicks wp-config endpoint
* WooCommerce HPOS and Blocks compatibility
* Full i18n support with .pot translation template

== Upgrade Notice ==

= 1.6.1 =
Smart-defaults on fresh install — when the CleanClicks server confirms your GA4 First-Party Mode is ready, the plugin now auto-enables the GA4 First-Party Proxy checkbox so new installs work out of the box. No behavior change for existing customers; current settings are preserved on update.

= 1.6.0 =
Two coordinated changes ship in this release. (1) Phase 8.2c onboarding polish:
zero-config setup (the "Client Domain" admin field is removed and the plugin
auto-detects your site domain from `home_url()`); pre-1.6.0 installs with a
manually-saved domain keep their value; activate-time remote-config prefetch
populates the 1-hour transient immediately. (2) Phase 1.6 v2 attribution recovery:
critical fixes for click-ID correlation under cookie-banner rejection. cc-wp.js
fetches now travel credentials properly (cc_pid stable per visitor); cookies
self-classify as functional so WP-Consent-API-integrated CMPs respect them;
consent gate split into always-on functional capture and consent-gated analytics
dispatch with deferred-queue drain on consent grant; OneTrust → WP Consent API
bridge built in; pre-webhook identify trigger populates CC_IDENT before the
WooCommerce order.created webhook delivers (covers Blocks checkouts where the
form-submit listener doesn't fire); WP Consent API service-level consent
preferred over category-level. Recommended for all sites using a CMP.

= 1.5.3 =
Fixes a long-standing origin-derivation bug for sites running on www.* subdomains.
Recommended for all WP Engine installations and any site where home_url() returns
a www. prefix.

= 1.5.2 =
Auto-installs the WooCommerce webhook on activation and adds a server-side payment-complete backstop, capturing purchases reliably across subscription renewals, custom thank-you pages, and offsite checkout returns. Eliminates the manual webhook setup step.

= 1.3.1 =
Switches Usermaven ecommerce events from client-side SDK bridging to server-side dispatch. Fixes Usermaven WooCommerce dashboards showing $0.

= 1.3.0 =
Fixes Usermaven Web Analytics showing empty dashboards on WP Rocket sites. Adds full WooCommerce event bridging to Usermaven.

= 1.0.1 =
Critical fix: Renamed generic CC_ constant and class prefixes to CLEANCLICKS_ to prevent activation failures caused by name collisions with other plugins.
