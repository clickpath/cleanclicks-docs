<?php
/**
 * Plugin Name:       CleanClicks
 * Plugin URI:        https://cleanclick.dev
 * Description:       First-party conversion tracking, click ID capture, attribution, and analytics proxy injection for WordPress and WooCommerce.
 * Version:           1.6.1
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            ClickPath Consultants
 * Author URI:        https://clickpathconsultants.com
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       cleanclicks-wp
 * Domain Path:       /languages
 * WC requires at least: 8.0
 * WC tested up to:   9.6
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CLEANCLICKS_VERSION', '1.6.1' );
define( 'CLEANCLICKS_PLUGIN_FILE', __FILE__ );
define( 'CLEANCLICKS_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CLEANCLICKS_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CLEANCLICKS_OPTION_KEY', 'cleanclicks_settings' );
define( 'CLEANCLICKS_CONFIG_TRANSIENT', 'cleanclicks_remote_config' );
define( 'CLEANCLICKS_CONFIG_TTL', HOUR_IN_SECONDS );

add_action( 'before_woocommerce_init', function () {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

add_action( 'init', function () {
	load_plugin_textdomain( 'cleanclicks-wp', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
} );

// D2-NEW-4 (Phase 1.6 v2): declare WP Consent API compliance. Surfaces the
// plugin in WP Consent API's "compliant plugins" list — some CMPs surface a
// "non-compliant plugins detected" warning to customers without this filter.
// Pairs with the service-level consent migration in cleanclicks_has_consent_for()
// below + cookie reclassification in class-cleanclicks-privacy.php.
add_filter( 'wp_consent_api_registered_' . plugin_basename( __FILE__ ), '__return_true' );

/**
 * D2-NEW-4: prefer service-level consent (WP Consent API v2.0+) over
 * category-level (v1.x). Service-level consent lets customers grant/deny
 * "cleanclicks" individually within Complianz / CookieYes / Iubenda service
 * toggle UIs, decoupling our consent state from generic 'statistics' or
 * 'marketing' categories that may also gate other tools.
 *
 * Returns true when consent for the cleanclicks service is granted at
 * service-level OR (fallback) the category-level consent is granted OR
 * (fallback) no Consent API is loaded at all (caller's outer
 * consent_required setting is the gate in that case).
 *
 * Returns false only when an explicit deny is observable from a loaded
 * Consent API.
 */
function cleanclicks_has_consent_for( $category = 'statistics' ) {
	if ( function_exists( 'wp_has_service_consent' ) ) {
		return (bool) wp_has_service_consent( 'cleanclicks' );
	}
	if ( function_exists( 'wp_has_consent' ) ) {
		return (bool) wp_has_consent( $category );
	}
	return true;
}

function cleanclicks_activate() {
	$is_fresh_install = ( false === get_option( CLEANCLICKS_OPTION_KEY ) );

	if ( $is_fresh_install ) {
		// v1.6.1 smart-defaults: try to apply server-side smart defaults first
		// (auto-enables GA4 First-Party Proxy when the server confirms full config
		// and the feature flag is ON). Falls through to safe all-OFF defaults if
		// anything fails — server unreachable, flag OFF, full-config gate fails.
		// Fresh-install gate is enforced inside the function as well, so reactivation
		// after a manual settings wipe still hits the same logic path safely.
		cleanclicks_apply_smart_defaults_on_fresh_install();

		// Safe-default fallback. If smart-defaults wrote the option, this no-ops.
		if ( false === get_option( CLEANCLICKS_OPTION_KEY ) ) {
			update_option( CLEANCLICKS_OPTION_KEY, cleanclicks_defaults() );
		}
	}

	// Flag the WC webhook for deferred creation. Actual creation runs
	// on woocommerce_init in the next request lifecycle (WC may not be
	// loaded inside register_activation_hook's context).
	if ( class_exists( 'CleanClicks_Webhook_Manager' ) ) {
		CleanClicks_Webhook_Manager::on_plugin_activation();
	}

	// Phase 8.2c (v1.6.0): force-fetch wp-config from cpath-proxy on activation so
	// the plugin starts with a hydrated 1-hour transient instead of waiting for the
	// first front-end request. Errors are silently swallowed by cleanclicks_remote_config()
	// when the proxy is unreachable — the lazy path on first hit covers that case.
	// On fresh install, smart-defaults already fetched + populated the transient (force=true
	// inside cleanclicks_apply_smart_defaults_on_fresh_install), so we'd otherwise double-fetch
	// here. Gate to non-fresh-install paths to save one HTTP roundtrip on activation.
	if ( ! $is_fresh_install ) {
		cleanclicks_remote_config( true );
	}
}
register_activation_hook( __FILE__, 'cleanclicks_activate' );

/**
 * v1.6.1 smart-defaults: if this is a fresh install (no existing cleanclicks_settings option),
 * fetch /__cc/wp-config and apply smart defaults when:
 *   - Server feature flag `defaults.smartDefaultsEnabled` is true (server-controlled gate)
 *   - Server confirms GA4 First-Party Mode ready: ga4Proxy.enabled + ga4Proxy.measurementId
 *   - Server confirms this is a WordPress install: top-level wpPluginMode === true
 *
 * Preserves customer choice on update + reactivation (fresh-install gate). Network failure
 * leaves defaults at safe all-OFF — plugin still activates cleanly.
 */
function cleanclicks_apply_smart_defaults_on_fresh_install() {
	// Fresh-install gate: only fire when no settings exist. Update + reactivation
	// paths preserve customer choice (the existing settings option is never overwritten).
	if ( false !== get_option( CLEANCLICKS_OPTION_KEY ) ) {
		return;
	}

	$client_domain = cleanclicks_client_domain();
	if ( empty( $client_domain ) ) {
		return; // No derivable domain — wp-config fetch would fail anyway.
	}

	// Fetch wp-config via the existing helper so we share the 1h transient with the
	// rest of the plugin. Force-refresh on fresh install since the transient won't
	// exist yet. wp_remote_get failures, malformed responses, and no-allowlist clients
	// all return an empty array — smart-defaults stays dormant in every failure mode.
	$config = cleanclicks_remote_config( true );
	if ( ! is_array( $config ) || empty( $config ) ) {
		return;
	}

	// Server flag gate. Gate ships DEFAULT OFF in cpath-proxy wrangler.toml; flips ON
	// post Phase 1.7 PASS (target Sat 2026-05-16) by editing the toml + wrangler deploy.
	$defaults_block = isset( $config['defaults'] ) && is_array( $config['defaults'] )
		? $config['defaults']
		: array();
	if ( empty( $defaults_block['smartDefaultsEnabled'] ) ) {
		return;
	}

	// Full-config gate. Smart-defaults only apply when ALL of these hold:
	//   - top-level wpPluginMode === true (this is a WordPress install, not a Shopify
	//     customer whose allowlist happens to have ga4Proxy enabled)
	//   - top-level ga4Proxy.enabled === true (server-side proxy mode is on)
	//   - top-level ga4Proxy.measurementId is a non-empty string
	// All three must be present for the auto-enable to be safe.
	$ga4p              = isset( $config['ga4Proxy'] ) && is_array( $config['ga4Proxy'] )
		? $config['ga4Proxy']
		: array();
	$is_wp_plugin_mode = ! empty( $config['wpPluginMode'] );
	$ga4p_enabled      = ! empty( $ga4p['enabled'] );
	$ga4p_mid          = ! empty( $ga4p['measurementId'] );

	if ( ! ( $is_wp_plugin_mode && $ga4p_enabled && $ga4p_mid ) ) {
		return;
	}

	// All gates passed — apply smart defaults. Start from the safe-default schema
	// so any field not explicitly overridden lands at its documented default value.
	// We DON'T invent new fields here — every key must already exist in cleanclicks_defaults().
	$smart_defaults                       = cleanclicks_defaults();
	$smart_defaults['enable_ga4_proxy']   = 1;
	$smart_defaults['ga4_measurement_id'] = (string) $ga4p['measurementId'];

	update_option( CLEANCLICKS_OPTION_KEY, $smart_defaults );

	// Audit-log: separate option records that smart defaults were applied. Helps
	// debug onboarding flows + provides a server-readable signal if cc-saas ever
	// surfaces a "smart-defaults applied" badge.
	update_option( 'cleanclicks_smart_defaults_applied', array(
		'version'        => CLEANCLICKS_VERSION,
		'applied_at'     => current_time( 'mysql', true ),
		'measurement_id' => (string) $ga4p['measurementId'],
		'wp_config_url'  => cleanclicks_origin() . '/__cc/wp-config',
	) );
}

function cleanclicks_deactivate() {
	delete_transient( CLEANCLICKS_CONFIG_TRANSIENT );
	delete_option( 'cleanclicks_usermaven_api_key' );
	delete_option( 'cleanclicks_usermaven_server_token' );
	delete_option( 'cleanclicks_usermaven_enabled' );
	delete_option( 'cleanclicks_usermaven_backfill_complete' );
	delete_option( 'cleanclicks_usermaven_backfill_offset' );
	delete_option( 'cleanclicks_usermaven_backfill_total' );
	wp_clear_scheduled_hook( 'cleanclicks_usermaven_backfill_batch' );

	// Remove the WC webhook so deactivation leaves a clean state.
	if ( class_exists( 'CleanClicks_Webhook_Manager' ) ) {
		CleanClicks_Webhook_Manager::on_plugin_deactivation();
	}
}
register_deactivation_hook( __FILE__, 'cleanclicks_deactivate' );

function cleanclicks_defaults() {
	return array(
		'client_domain'          => '',
		'origin_override'        => '',
		'consent_required'       => 0,
		'consent_category'       => 'statistics',
		'enable_ga4_proxy'       => 0,
		'ga4_measurement_id'     => '',
		'enable_usermaven_proxy' => 0,
		'enable_plerdy_proxy'    => 0,
		'enable_datalayer_push'  => 1,
		'debug'                  => 0,
		'inbound_api_key'        => '',
		// A4: configurable URL allowlist for purchase detection on custom
		// thank-you pages (subscription redirects, membership confirmations,
		// non-standard checkout completions). Standard /order-received/ is
		// still handled separately via the woocommerce_thankyou hook.
		'purchase_paths'         => array(
			'/order-received/',
			'/thank-you/',
			'/order-confirmation/',
			'/my-account/view-subscription/',
		),
		'purchase_path_regex'    => '',
	);
}

function cleanclicks_settings() {
	$saved = get_option( CLEANCLICKS_OPTION_KEY, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return array_merge( cleanclicks_defaults(), $saved );
}

function cleanclicks_origin() {
	$s        = cleanclicks_settings();
	$override = trim( (string) ( $s['origin_override'] ?? '' ) );
	if ( $override ) {
		return rtrim( $override, '/' );
	}
	$domain = cleanclicks_client_domain();
	return $domain ? 'https://cleanclicks.' . $domain : '';
}

function cleanclicks_client_domain() {
	$s      = cleanclicks_settings();
	$manual = trim( (string) ( $s['client_domain'] ?? '' ) );
	if ( $manual ) {
		return strtolower( $manual );
	}
	$parsed = wp_parse_url( home_url( '/' ) );
	$host   = isset( $parsed['host'] ) ? strtolower( $parsed['host'] ) : '';
	// Strip leading www. so WP Engine / www-subdomain installs derive the correct
	// cleanclicks.example.com origin rather than cleanclicks.www.example.com.
	if ( 0 === strpos( $host, 'www.' ) ) {
		$host = substr( $host, 4 );
	}
	return $host;
}

function cleanclicks_remote_config( $force_refresh = false ) {
	if ( ! $force_refresh ) {
		$cached = get_transient( CLEANCLICKS_CONFIG_TRANSIENT );
		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}
	}

	$origin = cleanclicks_origin();
	if ( ! $origin ) {
		return array();
	}

	$url      = $origin . '/__cc/wp-config?client=' . rawurlencode( cleanclicks_client_domain() );
	$response = wp_remote_get( $url, array(
		'timeout'   => 10,
		'sslverify' => true,
		'user-agent' => 'CleanClicks-WP/' . CLEANCLICKS_VERSION . ' (+' . home_url( '/' ) . ')',
	) );

	if ( is_wp_error( $response ) ) {
		return array();
	}

	$body = wp_remote_retrieve_body( $response );
	$data = json_decode( $body, true );

	if ( ! is_array( $data ) || empty( $data['ok'] ) ) {
		return array();
	}

	$config = isset( $data['config'] ) ? $data['config'] : array();
	set_transient( CLEANCLICKS_CONFIG_TRANSIENT, $config, CLEANCLICKS_CONFIG_TTL );
	return $config;
}

function cleanclicks_fetch_usermaven_credentials( $force = false ) {
	if ( ! $force ) {
		$key   = get_option( 'cleanclicks_usermaven_api_key', '' );
		$token = get_option( 'cleanclicks_usermaven_server_token', '' );
		if ( $key && $token ) {
			return true;
		}
	}

	$settings = get_option( CLEANCLICKS_OPTION_KEY, array() );
	$api_key  = isset( $settings['inbound_api_key'] ) ? $settings['inbound_api_key'] : '';
	$origin   = cleanclicks_origin();

	if ( ! $origin || ! $api_key ) {
		return false;
	}

	$url      = $origin . '/__cc/wp-credentials?client=' . rawurlencode( cleanclicks_client_domain() );
	$response = wp_remote_post( $url, array(
		'timeout'    => 10,
		'sslverify'  => true,
		'headers'    => array(
			'X-CC-Api-Key' => $api_key,
		),
		'user-agent' => 'CleanClicks-WP/' . CLEANCLICKS_VERSION . ' (+' . home_url( '/' ) . ')',
	) );

	if ( is_wp_error( $response ) ) {
		return false;
	}

	$body = json_decode( wp_remote_retrieve_body( $response ), true );
	if ( ! is_array( $body ) || empty( $body['ok'] ) ) {
		return false;
	}

	$um_key     = isset( $body['usermaven_api_key'] ) ? sanitize_text_field( $body['usermaven_api_key'] ) : '';
	$um_token   = isset( $body['usermaven_server_token'] ) ? sanitize_text_field( $body['usermaven_server_token'] ) : '';
	$um_enabled = ! empty( $body['usermaven_enabled'] );

	update_option( 'cleanclicks_usermaven_api_key', $um_key );
	update_option( 'cleanclicks_usermaven_server_token', $um_token );
	update_option( 'cleanclicks_usermaven_enabled', $um_enabled ? '1' : '0' );

	return ( $um_key && $um_token );
}

require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-admin.php';
require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-tracker.php';
require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-proxies.php';
require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-privacy.php';
require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-webhook-manager.php';

if ( class_exists( 'WooCommerce' ) || function_exists( 'WC' ) ) {
	require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-woocommerce.php';
}

add_action( 'woocommerce_loaded', function () {
	if ( ! class_exists( 'CleanClicks_WooCommerce' ) ) {
		require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-woocommerce.php';
	}
} );

add_action( 'woocommerce_loaded', function () {
	if ( ! class_exists( 'CleanClicks_Usermaven_WooCommerce' ) ) {
		$um_key   = get_option( 'cleanclicks_usermaven_api_key', '' );
		$um_token = get_option( 'cleanclicks_usermaven_server_token', '' );
		$um_on    = get_option( 'cleanclicks_usermaven_enabled', '0' );
		if ( $um_key && $um_token && $um_on === '1' ) {
			require_once CLEANCLICKS_PLUGIN_DIR . 'includes/class-cleanclicks-usermaven-woocommerce.php';
			CleanClicks_Usermaven_WooCommerce::init( $um_key, $um_token );
		}
	}
}, 20 );

CleanClicks_Admin::init();
CleanClicks_Tracker::init();
CleanClicks_Proxies::init();
CleanClicks_Privacy::init();
