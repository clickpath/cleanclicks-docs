<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_WooCommerce {

	public static function init() {

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_ecommerce_data' ), 20 );

		add_action( 'woocommerce_thankyou', array( __CLASS__, 'inject_purchase' ), 10, 1 );

		add_action( 'wp_footer', array( __CLASS__, 'add_to_cart_listeners' ), 99 );

		// Stash product data on add-to-cart for non-AJAX redirect stores.
		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'stash_add_to_cart' ), 10, 6 );

		// Inject cart data on cart page for checkout intent detection.
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'inject_cart_page_data' ), 21 );

		// A3: server-side backstop for payment-complete events. Fires regardless of
		// whether the customer ever loads /order-received/ — covers subscription
		// renewals, custom thank-you flows, offsite-checkout returns. Posts to the
		// same /__cc/woocommerce/webhook endpoint as the WC webhook (A1) so dedup
		// by woo:{domain}:{orderId} prevents double-dispatch.
		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'dispatch_payment_complete' ), 99, 1 );

		// A4: client-side purchase capture on configurable thank-you URLs. Catches
		// custom flows that aren't is_order_received_page() (e.g., scm-platinum,
		// /thank-you/, subscription confirmations). The standard /order-received/
		// path is still handled by woocommerce_thankyou (don't double-fire).
		add_action( 'wp_footer', array( __CLASS__, 'detect_custom_purchase_page' ), 50 );

		// D2-NEW-3 (Phase 1.6 v2): pre-webhook identify trigger. Server-renders
		// a pre_purchase_identify event with customer's hashed_email when the
		// checkout page renders, so CC_IDENT is populated BEFORE the WC
		// order.created webhook delivers. Fires on both classic AND WC Blocks
		// checkouts (wp_footer always runs). Critical for SCM (Blocks per F-11)
		// where watchForms doesn't catch the React/AJAX submit. Priority 5 keeps
		// the queue push before the cleanclicks-wp script loads.
		add_action( 'wp_footer', array( __CLASS__, 'inject_pre_purchase_identify' ), 5 );
	}

	public static function stash_add_to_cart( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
		if ( ! WC()->session ) {
			return;
		}

		WC()->session->set( 'cc_pending_atc', array(
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'quantity'     => $quantity,
			'timestamp'    => time(),
		) );
	}

	public static function inject_cart_page_data() {
		if ( ! function_exists( 'is_cart' ) || ! is_cart() ) {
			return;
		}

		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			return;
		}

		$cart = WC()->cart;
		if ( ! $cart || $cart->is_empty() ) {
			return;
		}

		// ── Non-AJAX add_to_cart: consume the session stash ──
		$pending = WC()->session ? WC()->session->get( 'cc_pending_atc' ) : null;
		if ( $pending && isset( $pending['timestamp'] ) && ( time() - $pending['timestamp'] ) < 30 ) {
			$pid  = ! empty( $pending['variation_id'] ) ? $pending['variation_id'] : $pending['product_id'];
			$prod = wc_get_product( $pid );
			if ( $prod ) {
				$item = self::map_product_to_ga4_item( $prod );
				$item['quantity'] = (int) $pending['quantity'];

				$atc_event = array(
					'name'    => 'add_to_cart',
					'payload' => array(
						'currency' => get_woocommerce_currency(),
						'value'    => (float) $prod->get_price() * (int) $pending['quantity'],
						'items'    => array( $item ),
					),
				);

				wp_add_inline_script(
					'cleanclicks-wp',
					'window.__ccwpQueue=(window.__ccwpQueue||[]).concat(' . wp_json_encode( array( $atc_event ) ) . ');',
					'before'
				);
			}
			WC()->session->set( 'cc_pending_atc', null );
		}

		// ── Cart data for checkout intent detection ──
		$items = array();
		foreach ( $cart->get_cart() as $cart_item ) {
			$prod = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
			if ( ! $prod ) {
				continue;
			}
			$item             = self::map_product_to_ga4_item( $prod );
			$item['quantity'] = (int) ( $cart_item['quantity'] ?? 1 );
			$items[]          = $item;
		}

		if ( ! empty( $items ) ) {
			wp_add_inline_script(
				'cleanclicks-wp',
				'window.__ccwpCartData=' . wp_json_encode( array(
					'value'    => (float) $cart->get_cart_contents_total(),
					'currency' => get_woocommerce_currency(),
					'items'    => $items,
				) ) . ';',
				'before'
			);
		}
	}

	private static function get_view_item_payload() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return null;
		}

		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return null;
		}

		$item = self::map_product_to_ga4_item( $product );

		return array(
			'name'    => 'view_item',
			'payload' => array(
				'currency' => get_woocommerce_currency(),
				'value'    => (float) $product->get_price(),
				'items'    => array( $item ),
			),
		);
	}

	private static function get_view_item_list_payload() {
		if ( ! function_exists( 'is_shop' ) ) {
			return null;
		}
		if ( ! is_shop() && ! is_product_category() && ! is_product_tag() && ! is_product_taxonomy() ) {
			return null;
		}

		global $wp_query;
		if ( ! $wp_query || empty( $wp_query->posts ) ) {
			return null;
		}

		$list_name = 'Shop';
		if ( is_product_category() ) {
			$term      = get_queried_object();
			$list_name = $term ? $term->name : 'Category';
		} elseif ( is_product_tag() ) {
			$term      = get_queried_object();
			$list_name = $term ? $term->name : 'Tag';
		}

		$items = array();
		$index = 0;
		foreach ( $wp_query->posts as $post ) {
			$prod = wc_get_product( $post->ID );
			if ( ! $prod ) {
				continue;
			}
			$item                  = self::map_product_to_ga4_item( $prod );
			$item['index']         = $index;
			$item['item_list_name'] = $list_name;
			$items[]               = $item;
			$index++;
			if ( $index >= 50 ) {
				break;
			}
		}

		if ( empty( $items ) ) {
			return null;
		}

		return array(
			'name'    => 'view_item_list',
			'payload' => array(
				'item_list_name' => $list_name,
				'items'          => $items,
			),
		);
	}

	private static function get_begin_checkout_payload() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return null;
		}

		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return null;
		}

		$cart = WC()->cart;
		if ( ! $cart ) {
			return null;
		}

		$items   = array();
		$coupons = $cart->get_applied_coupons();

		foreach ( $cart->get_cart() as $cart_item ) {
			$prod = isset( $cart_item['data'] ) ? $cart_item['data'] : null;
			if ( ! $prod ) {
				continue;
			}
			$item = self::map_product_to_ga4_item( $prod );
			$item['quantity'] = (int) ( $cart_item['quantity'] ?? 1 );
			if ( ! empty( $coupons ) ) {
				$item['coupon'] = implode( ',', $coupons );
			}
			$items[] = $item;
		}

		return array(
			'name'    => 'begin_checkout',
			'payload' => array(
				'currency' => get_woocommerce_currency(),
				'value'    => (float) $cart->get_cart_contents_total(),
				'coupon'   => ! empty( $coupons ) ? implode( ',', $coupons ) : '',
				'items'    => $items,
			),
		);
	}

	/**
	 * A3: server-side backstop for payment_complete events.
	 *
	 * Fires when a payment completes regardless of whether the customer ever
	 * lands on /order-received/. Covers:
	 *   - Subscription renewals (cron-driven, no customer present)
	 *   - Custom thank-you pages (customer never hits standard order-received URL)
	 *   - Offsite payment processors that redirect away (Stripe Checkout, etc.)
	 *   - Membership signups that skip the standard thank-you flow
	 *
	 * Posts to /__cc/woocommerce/webhook with HMAC-SHA256 signature using the
	 * inbound_api_key as secret (same code path + dedup key as the A1
	 * register_activation_hook webhook, so duplicate deliveries dedupe naturally
	 * via cpath-proxy's woo:{domain}:{orderId} key with 24h TTL).
	 *
	 * Idempotency: marks _cc_server_dispatched on the order to prevent re-fire
	 * within the local plugin lifecycle. The wp_remote_post is non-blocking
	 * (fire-and-forget) to avoid adding latency to synchronous checkout flows.
	 */
	public static function dispatch_payment_complete( $order_id ) {
		if ( ! $order_id ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		// Idempotency — separate meta from _cc_tracked (which is the client-side path).
		if ( $order->get_meta( '_cc_server_dispatched' ) === 'yes' ) {
			return;
		}

		$settings = cleanclicks_settings();
		$api_key  = isset( $settings['inbound_api_key'] ) ? trim( (string) $settings['inbound_api_key'] ) : '';
		if ( '' === $api_key ) {
			return; // Nothing to sign with; no point dispatching.
		}

		$origin = cleanclicks_origin();
		if ( empty( $origin ) ) {
			return;
		}

		$delivery_url = $origin . '/__cc/woocommerce/webhook';

		// Build a minimal WC-webhook-shaped payload — just the fields cpath-proxy's
		// handleWooCommerceWebhook reads. Smaller payload = faster signing + transit.
		$line_items = array();
		foreach ( $order->get_items() as $item ) {
			$prod         = $item->get_product();
			$line_items[] = array(
				'id'       => (int) $item->get_id(),
				'name'     => (string) $item->get_name(),
				'sku'      => $prod ? (string) $prod->get_sku() : '',
				'quantity' => (int) $item->get_quantity(),
				'price'    => (string) $order->get_item_total( $item, false, true ),
				'total'    => (string) $item->get_total(),
			);
			if ( count( $line_items ) >= 50 ) {
				break;
			}
		}

		$payload = array(
			'id'         => (int) $order->get_id(),
			'number'     => (string) $order->get_order_number(),
			'status'     => (string) $order->get_status(), // e.g. "processing", "completed"
			'currency'   => (string) $order->get_currency(),
			'total'      => (string) $order->get_total(),
			'billing'    => array(
				'email' => (string) $order->get_billing_email(),
			),
			'line_items' => $line_items,
		);

		$body = wp_json_encode( $payload );
		if ( false === $body ) {
			return;
		}

		// HMAC-SHA256, base64-encoded — same algorithm WC uses for native webhook
		// delivery, so cpath-proxy's verifyWebhookHmac() validates without changes.
		$signature = base64_encode( hash_hmac( 'sha256', $body, $api_key, true ) );

		$response = wp_remote_post( $delivery_url, array(
			'method'      => 'POST',
			'timeout'     => 10,
			'blocking'    => false, // fire-and-forget: do not delay checkout flow
			'redirection' => 0,
			'sslverify'   => true,
			'headers'     => array(
				'Content-Type'           => 'application/json',
				'User-Agent'             => 'CleanClicks-WP/' . CLEANCLICKS_VERSION . ' (server-payment-complete)',
				'X-WC-Webhook-Signature' => $signature,
				'X-WC-Webhook-Timestamp' => (string) time(),
				'X-WC-Webhook-Topic'     => 'order.updated',
				'X-WC-Webhook-Source'    => home_url( '/' ),
				'X-CC-Source'            => 'plugin_payment_complete', // disambiguates from native WC webhook delivery
			),
			'body'        => $body,
		) );

		// Mark idempotent regardless of response — blocking=false means we can't
		// confirm 2xx, and retry-on-failure within the same payment_complete fire
		// would risk hammering cpath-proxy. The customer's data flows are eventually
		// consistent: any transient failure is logged in cpath-proxy audit and
		// can be replayed via the admin webhook UI if needed.
		$order->update_meta_data( '_cc_server_dispatched', 'yes' );
		$order->save();
	}

	/**
	 * A4: detect purchase events on custom thank-you URLs.
	 *
	 * Runs on every wp_footer. Cheap path-string check first; only does
	 * order-resolution work if the current URL matches the configured
	 * purchase_paths or purchase_path_regex setting.
	 *
	 * Filter hooks for programmatic extension:
	 *   cleanclicks_purchase_paths       — array of substrings to match in URL path
	 *   cleanclicks_purchase_path_regex  — regex pattern (no delimiters)
	 *   cleanclicks_resolve_order_id     — int, override the resolved order ID
	 */
	public static function detect_custom_purchase_page() {
		// Skip on admin / api / cron — same gate as the tracker.
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}

		// Standard /order-received/ already handled by woocommerce_thankyou hook.
		// Skipping here prevents this path from firing redundantly. (The
		// _cc_tracked order meta also prevents double-fire defensively.)
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return;
		}

		if ( ! self::current_url_matches_purchase_paths() ) {
			return;
		}

		$order_id = self::resolve_order_id_from_request();
		$order_id = (int) apply_filters( 'cleanclicks_resolve_order_id', $order_id );
		if ( ! $order_id ) {
			return;
		}

		// Reuses inject_purchase, which has its own _cc_tracked guard so
		// repeated detections within the same order lifecycle are no-ops.
		self::inject_purchase( $order_id );
	}

	/**
	 * Returns true if the current request's URL path matches any configured
	 * purchase_path entry (substring match) or purchase_path_regex.
	 */
	private static function current_url_matches_purchase_paths() {
		$settings = cleanclicks_settings();

		$paths = isset( $settings['purchase_paths'] ) && is_array( $settings['purchase_paths'] )
			? $settings['purchase_paths']
			: array();

		// Allow site admins to extend programmatically without touching settings.
		$paths = apply_filters( 'cleanclicks_purchase_paths', $paths );

		$regex = isset( $settings['purchase_path_regex'] ) ? trim( (string) $settings['purchase_path_regex'] ) : '';
		$regex = (string) apply_filters( 'cleanclicks_purchase_path_regex', $regex );

		// REQUEST_URI is always set by PHP-FPM; default empty for safety.
		$request_uri  = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		$current_path = (string) wp_parse_url( $request_uri, PHP_URL_PATH );

		if ( '' === $current_path ) {
			return false;
		}

		foreach ( (array) $paths as $needle ) {
			$needle = trim( (string) $needle );
			if ( '' === $needle ) {
				continue;
			}
			if ( false !== strpos( $current_path, $needle ) ) {
				return true;
			}
		}

		if ( '' !== $regex ) {
			// Wrap with unique delimiter, escape any literal occurrence in the user input.
			$pattern = '~' . str_replace( '~', '\~', $regex ) . '~';
			// preg_match returns false on regex error, 0 on no match, 1 on match.
			$result = @preg_match( $pattern, $current_path );
			if ( 1 === $result ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Resolve a WC order ID from the current request. Tries (in order):
	 *   1. ?order_id= / ?order-received= / ?order= query params
	 *   2. ?key=wc_order_* via wc_get_order_id_by_order_key
	 *   3. Most recent recent order for the logged-in customer
	 *
	 * Returns 0 if nothing resolves.
	 */
	private static function resolve_order_id_from_request() {
		$candidate = 0;

		if ( isset( $_GET['order_id'] ) ) {
			$candidate = absint( $_GET['order_id'] );
		} elseif ( isset( $_GET['order-received'] ) ) {
			$candidate = absint( $_GET['order-received'] );
		} elseif ( isset( $_GET['order'] ) ) {
			$candidate = absint( $_GET['order'] );
		}

		if ( $candidate ) {
			return $candidate;
		}

		// WC order key fallback (e.g., ?key=wc_order_abc123)
		if ( isset( $_GET['key'] ) ) {
			$key = sanitize_text_field( wp_unslash( $_GET['key'] ) );
			if ( '' !== $key && function_exists( 'wc_get_order_id_by_order_key' ) ) {
				$candidate = (int) wc_get_order_id_by_order_key( $key );
				if ( $candidate ) {
					return $candidate;
				}
			}
		}

		// Logged-in customer's most recent order (within a sensible recency window).
		if ( is_user_logged_in() && function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders( array(
				'customer' => get_current_user_id(),
				'limit'    => 1,
				'orderby'  => 'date',
				'order'    => 'DESC',
				'status'   => array( 'processing', 'completed', 'on-hold' ),
				'date_after' => gmdate( 'Y-m-d H:i:s', time() - DAY_IN_SECONDS ),
			) );
			if ( ! empty( $orders ) && is_a( $orders[0], 'WC_Order' ) ) {
				return (int) $orders[0]->get_id();
			}
		}

		return 0;
	}

	/**
	 * D2-NEW-3 (Phase 1.6 v2): pre-webhook identify trigger.
	 *
	 * Server-renders a pre_purchase_identify event with the customer's hashed
	 * billing_email when the WC checkout page renders. Populates CC_IDENT
	 * BEFORE the WC order.created webhook delivers, so lookupClickIdsByEmail()
	 * finds the click-ID correlation and conv writes have has_clickids: true
	 * even on first-time guest checkouts.
	 *
	 * Why this exists: cc-wp.js's watchForms (form-submit listener) doesn't
	 * fire on WC Blocks checkouts (React + AJAX submit). SCM is Blocks-based
	 * (verified F-11), so the classic-checkout-only path leaves SCM with
	 * has_clickids: 0/12 even with all other fixes shipped. PHP-side
	 * server-render guarantees identify fires regardless of checkout type.
	 *
	 * Hook: wp_footer priority 5. Fires on BOTH classic and Blocks checkouts.
	 * is_checkout() gate prevents pollution on non-checkout pages. Priority 5
	 * keeps the queue push before priority 50 (detect_custom_purchase_page)
	 * and before script execution (cleanclicks-wp is enqueued in the footer
	 * with strategy:defer).
	 *
	 * Trigger conditions:
	 *   - Logged-in customer with billing_email user_meta or user_email
	 *   - Returning guest with WC session-cached billing_email
	 * Guests with no cached email rely on the cc-wp.js watchEmailInputs
	 * listener (debounced input handler) to fire identify once they type.
	 *
	 * Privacy: hashed_email is SHA-256 of normalized billing_email. The
	 * cpath-proxy /__cc/identify handler is opt-out aware — under reject
	 * (GPC / cc_ss_optout), it skips the forward mapping and stores the
	 * reverse mapping with opted_out: true (used only for click-ID
	 * correlation, never dispatched to vendors under measurement_only).
	 */
	public static function inject_pre_purchase_identify() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
			return;
		}
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return;
		}
		// Order-received pages are handled separately by inject_purchase via the
		// woocommerce_thankyou hook + detect_custom_purchase_page. Skip here.
		if ( function_exists( 'is_order_received_page' ) && is_order_received_page() ) {
			return;
		}

		$email = self::resolve_customer_email();
		if ( ! $email ) {
			return; // No known email — JS-side watchEmailInputs covers guest path.
		}

		$hashed = self::hash_email_normalized( $email );
		if ( ! $hashed ) {
			return;
		}

		$event = array(
			'name'    => 'pre_purchase_identify',
			'payload' => array(
				'_hashed_email' => $hashed,
				'source'        => 'checkout_render',
			),
		);

		wp_add_inline_script(
			'cleanclicks-wp',
			'window.__ccwpQueue=(window.__ccwpQueue||[]).concat(' . wp_json_encode( array( $event ) ) . ');',
			'before'
		);
	}

	/**
	 * Resolve the customer's billing email at checkout-render time. Returns
	 * empty string if nothing resolves (guest with no cached email — the
	 * cc-wp.js watchEmailInputs listener handles that path).
	 */
	private static function resolve_customer_email() {
		if ( is_user_logged_in() ) {
			$user_id = get_current_user_id();
			if ( $user_id ) {
				$billing = get_user_meta( $user_id, 'billing_email', true );
				if ( $billing && is_email( $billing ) ) {
					return (string) $billing;
				}
				$user = wp_get_current_user();
				if ( $user && ! empty( $user->user_email ) && is_email( $user->user_email ) ) {
					return (string) $user->user_email;
				}
			}
		}

		if ( function_exists( 'WC' ) && WC() ) {
			// WC Customer object holds billing email during the checkout flow.
			$customer = WC()->customer;
			if ( $customer && method_exists( $customer, 'get_billing_email' ) ) {
				$cust_email = $customer->get_billing_email();
				if ( $cust_email && is_email( $cust_email ) ) {
					return (string) $cust_email;
				}
			}

			if ( WC()->session ) {
				$session_email = WC()->session->get( 'billing_email' );
				if ( $session_email && is_email( $session_email ) ) {
					return (string) $session_email;
				}
			}
		}

		return '';
	}

	public static function inject_purchase( $order_id ) {
		if ( ! $order_id ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}

		if ( $order->get_meta( '_cc_tracked' ) === 'yes' ) {
			return;
		}

		$items   = array();
		$coupons = $order->get_coupon_codes();

		foreach ( $order->get_items() as $item ) {
			$prod = $item->get_product();
			if ( ! $prod ) {
				continue;
			}
			$ga4_item             = self::map_product_to_ga4_item( $prod );
			$ga4_item['quantity'] = (int) $item->get_quantity();
			$ga4_item['price']    = (float) $order->get_item_total( $item, false, true );
			if ( ! empty( $coupons ) ) {
				$ga4_item['coupon'] = implode( ',', $coupons );
			}
			$items[] = $ga4_item;
		}

		$billing_email = $order->get_billing_email();

		$hashed_email = '';
		if ( $billing_email ) {
			$hashed_email = self::hash_email_normalized( $billing_email );
		}

		$purchase_data = array(
			'name'    => 'purchase',
			'payload' => array(
				'orderid'       => (string) $order->get_order_number(),
				'currency'      => (string) $order->get_currency(),
				'value'         => (float) $order->get_total(),
				'tax'           => (float) $order->get_total_tax(),
				'shipping'      => (float) $order->get_shipping_total(),
				'coupon'        => ! empty( $coupons ) ? implode( ',', $coupons ) : '',
				'items'         => $items,
				'_hashed_email' => $hashed_email,
			),
		);

		$order->update_meta_data( '_cc_tracked', 'yes' );
		$order->save();

		$queue = wp_json_encode( array( $purchase_data ) );
		wp_add_inline_script(
			'cleanclicks-wp',
			'window.__ccwpQueue=(window.__ccwpQueue||[]).concat(' . $queue . ');',
			'before'
		);
	}

	public static function enqueue_ecommerce_data() {
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return;
		}

		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			return;
		}

		$queue = array();

		$vi = self::get_view_item_payload();
		if ( $vi ) {
			$queue[] = $vi;
		}

		$vil = self::get_view_item_list_payload();
		if ( $vil ) {
			$queue[] = $vil;
		}

		$bc = self::get_begin_checkout_payload();
		if ( $bc ) {
			$queue[] = $bc;
		}

		if ( ! empty( $queue ) ) {
			wp_add_inline_script(
				'cleanclicks-wp',
				'window.__ccwpQueue=(window.__ccwpQueue||[]).concat(' . wp_json_encode( $queue ) . ');',
				'before'
			);
		}
	}

	public static function add_to_cart_listeners() {
		if ( ! function_exists( 'is_woocommerce' ) && ! function_exists( 'is_cart' ) ) {
			return;
		}

		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			return;
		}

		$currency = get_woocommerce_currency();
		?>
		<script id="cleanclicks-wc-atc-listeners">
		(function(){
			var cfg = window.__ccwp || {};
			var currency = <?php echo wp_json_encode( $currency ); ?>;

			if (typeof jQuery !== 'undefined') {
				jQuery(document.body).on('added_to_cart', function(e, fragments, hash, btn) {
					if (!btn || !btn.length) return;
					var id = btn.data('product_id') || btn.attr('data-product_id') || '';
					var name = btn.data('product_name') || '';
					var price = parseFloat(btn.data('price') || 0);
					var ev = {
						name: 'add_to_cart',
						payload: {
							currency: currency,
							value: price,
							items: id ? [{ item_id: String(id), item_name: String(name), price: price, quantity: 1 }] : []
						}
					};
					window.__ccwpQueue = (window.__ccwpQueue || []).concat([ev]);
					if (window.__ccwpProcessQueue) window.__ccwpProcessQueue();
				});
			}

			document.addEventListener('wc-blocks_added_to_cart', function(e) {
				var ev = {
					name: 'add_to_cart',
					payload: { currency: currency, value: 0, items: [] }
				};
				window.__ccwpQueue = (window.__ccwpQueue || []).concat([ev]);
				if (window.__ccwpProcessQueue) window.__ccwpProcessQueue();
			});

			var form = document.querySelector('form.cart');
			if (form) {
				form.addEventListener('submit', function() {
					var prodEl = form.querySelector('[name="add-to-cart"]');
					var qtyEl = form.querySelector('[name="quantity"]');
					if (!prodEl) return;
					var id = prodEl.value;
					var qty = qtyEl ? parseInt(qtyEl.value, 10) || 1 : 1;

					var price = 0;
					var nameEl = document.querySelector('.product_title');
					var priceEl = document.querySelector('.price .woocommerce-Price-amount bdi');
					if (priceEl) price = parseFloat(priceEl.textContent.replace(/[^0-9.]/g, '')) || 0;

					var ev = {
						name: 'add_to_cart',
						payload: {
							currency: currency,
							value: price * qty,
							items: [{ item_id: String(id), item_name: nameEl ? nameEl.textContent.trim() : '', price: price, quantity: qty }]
						}
					};
					window.__ccwpQueue = (window.__ccwpQueue || []).concat([ev]);
					if (window.__ccwpProcessQueue) window.__ccwpProcessQueue();
				});
			}
		})();
		</script>
		<?php
	}

	private static function map_product_to_ga4_item( $product ) {
		$item = array(
			'item_id'   => (string) $product->get_sku() ?: (string) $product->get_id(),
			'item_name' => (string) $product->get_name(),
			'price'     => (float) $product->get_price(),
			'quantity'  => 1,
		);

		$brand = '';
		if ( function_exists( 'yith_wcbr_get_brand' ) ) {
			$brand_terms = get_the_terms( $product->get_id(), 'yith_product_brand' );
			if ( $brand_terms && ! is_wp_error( $brand_terms ) ) {
				$brand = $brand_terms[0]->name;
			}
		}
		if ( ! $brand ) {
			$brand_terms = get_the_terms( $product->get_id(), 'product_brand' );
			if ( $brand_terms && ! is_wp_error( $brand_terms ) ) {
				$brand = $brand_terms[0]->name;
			}
		}
		if ( $brand ) {
			$item['item_brand'] = $brand;
		}

		$cat_terms = get_the_terms( $product->get_id(), 'product_cat' );
		if ( $cat_terms && ! is_wp_error( $cat_terms ) ) {
			$cat_names = wp_list_pluck( $cat_terms, 'name' );
			$cat_names = array_values( array_slice( $cat_names, 0, 5 ) );
			foreach ( $cat_names as $i => $cat_name ) {
				$key          = $i === 0 ? 'item_category' : 'item_category' . ( $i + 1 );
				$item[ $key ] = $cat_name;
			}
		}

		if ( $product->is_type( 'variation' ) && method_exists( $product, 'get_attributes' ) ) {
			$attrs = $product->get_attributes();
			if ( ! empty( $attrs ) ) {
				$item['item_variant'] = implode( ' / ', array_values( $attrs ) );
			}
		}

		return $item;
	}

	private static function hash_email_normalized( $email ) {
		$email = strtolower( trim( $email ) );
		$at    = strrpos( $email, '@' );
		if ( false === $at || 0 === $at ) {
			return '';
		}

		$local  = trim( substr( $email, 0, $at ) );
		$domain = trim( substr( $email, $at + 1 ) );
		if ( '' === $local || '' === $domain ) {
			return '';
		}

		if ( 'googlemail.com' === $domain ) {
			$domain = 'gmail.com';
		}
		if ( 'gmail.com' === $domain ) {
			$plus = strpos( $local, '+' );
			if ( false !== $plus ) {
				$local = substr( $local, 0, $plus );
			}
			$local = str_replace( '.', '', $local );
		}

		return hash( 'sha256', $local . '@' . $domain );
	}
}

CleanClicks_WooCommerce::init();
