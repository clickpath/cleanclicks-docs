<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_Admin {

	const SLUG     = 'cleanclicks';
	const GROUP    = 'cleanclicks_group';
	const SECTION  = 'cleanclicks_main';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_admin_assets' ) );
		add_action( 'admin_notices', array( __CLASS__, 'maybe_show_backfill_notice' ) );

		add_action( 'wp_ajax_cleanclicks_test_connection', array( __CLASS__, 'ajax_test_connection' ) );

		add_action( 'wp_ajax_cleanclicks_refresh_config', array( __CLASS__, 'ajax_refresh_config' ) );

		// A5: webhook recreate handler
		add_action( 'wp_ajax_cleanclicks_recreate_webhook', array( __CLASS__, 'ajax_recreate_webhook' ) );
	}

	public static function register_menu() {

		add_menu_page(
			esc_html__( 'CleanClicks', 'cleanclicks-wp' ),
			esc_html__( 'CleanClicks', 'cleanclicks-wp' ),
			'manage_options',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			'dashicons-chart-area',
			58
		);
	}

	public static function register_settings() {
		register_setting( self::GROUP, CLEANCLICKS_OPTION_KEY, array(
			'type'              => 'array',
			'sanitize_callback' => array( __CLASS__, 'sanitize' ),
		) );

		add_settings_section(
			'cleanclicks_connection',
			esc_html__( 'Connection', 'cleanclicks-wp' ),
			function () {
				echo '<p>' . esc_html__( 'Configure how this site connects to your CleanClicks tracking endpoint.', 'cleanclicks-wp' ) . '</p>';
			},
			self::SLUG
		);

		// Phase 8.2c (v1.6.0): "Client Domain" admin input removed. Domain is now
		// auto-detected from `home_url()` with a leading-`www.` strip (v1.5.3 fix).
		// Manual override preserved server-side via `cleanclicks_client_domain()` if a
		// pre-1.6.0 install already saved a value, but new installs never see the field.

		self::add_field( 'origin_override', __( 'Origin Override', 'cleanclicks-wp' ), 'cleanclicks_connection', 'render_field_text', array(
			'placeholder' => 'https://cleanclicks.example.com',
			'description' => __( 'Override the CleanClicks proxy origin. Leave blank to auto-use https://cleanclicks.&lt;domain&gt;.', 'cleanclicks-wp' ),
			'style'       => 'width:420px;',
		) );

		self::add_field( 'inbound_api_key', __( 'Inbound API Key', 'cleanclicks-wp' ), 'cleanclicks_connection', 'render_field_text', array(
			'placeholder' => 'your-api-key-here',
			'description' => __( 'API key from CleanClicks Integrations tab. Required for Usermaven WooCommerce tracking.', 'cleanclicks-wp' ),
			'style'       => 'width:320px;',
		) );

		add_settings_section(
			'cleanclicks_proxies',
			esc_html__( 'Analytics Proxies', 'cleanclicks-wp' ),
			function () {
				echo '<p>' . esc_html__( 'Inject first-party proxy scripts for analytics platforms. These route traffic through your CleanClicks subdomain to bypass ad blockers.', 'cleanclicks-wp' ) . '</p>';
			},
			self::SLUG
		);

		self::add_field( 'enable_ga4_proxy', __( 'GA4 First-Party Proxy', 'cleanclicks-wp' ), 'cleanclicks_proxies', 'render_field_checkbox', array(
			'label' => __( 'Route GA4 (gtag.js) through CleanClicks proxy', 'cleanclicks-wp' ),
		) );

		self::add_field( 'ga4_measurement_id', __( 'GA4 Measurement ID', 'cleanclicks-wp' ), 'cleanclicks_proxies', 'render_field_text', array(
			'placeholder' => 'G-XXXXXXXXXX',
			'description' => __( 'Required when GA4 proxy is enabled. Pulled from remote config if left blank.', 'cleanclicks-wp' ),
			'style'       => 'width:200px;',
		) );

		self::add_field( 'enable_usermaven_proxy', __( 'Usermaven Proxy', 'cleanclicks-wp' ), 'cleanclicks_proxies', 'render_field_checkbox', array(
			'label' => __( 'Inject Usermaven tracking via CleanClicks proxy', 'cleanclicks-wp' ),
		) );

		self::add_field( 'enable_plerdy_proxy', __( 'Plerdy Proxy', 'cleanclicks-wp' ), 'cleanclicks_proxies', 'render_field_checkbox', array(
			'label' => __( 'Inject Plerdy tracking via CleanClicks proxy', 'cleanclicks-wp' ),
		) );

		add_settings_section(
			'cleanclicks_privacy',
			esc_html__( 'Privacy & Consent', 'cleanclicks-wp' ),
			function () {
				echo '<p>' . esc_html__( 'Control how tracking scripts interact with consent management.', 'cleanclicks-wp' ) . '</p>';
			},
			self::SLUG
		);

		self::add_field( 'consent_required', __( 'Require Consent', 'cleanclicks-wp' ), 'cleanclicks_privacy', 'render_field_checkbox', array(
			'label' => __( 'Only load tracking after visitor grants consent (recommended for GDPR/EU sites)', 'cleanclicks-wp' ),
		) );

		self::add_field( 'consent_category', __( 'Consent Category', 'cleanclicks-wp' ), 'cleanclicks_privacy', 'render_field_select', array(
			'options'     => array(
				'statistics'           => __( 'Statistics', 'cleanclicks-wp' ),
				'statistics-anonymous' => __( 'Statistics (Anonymous)', 'cleanclicks-wp' ),
				'marketing'            => __( 'Marketing', 'cleanclicks-wp' ),
			),
			'description' => __( 'WP Consent API category to check. "Statistics" works with most consent plugins.', 'cleanclicks-wp' ),
		) );

		add_settings_section(
			'cleanclicks_behavior',
			esc_html__( 'Behavior', 'cleanclicks-wp' ),
			function () {
				echo '<p>' . esc_html__( 'Fine-tune tracking behavior.', 'cleanclicks-wp' ) . '</p>';
			},
			self::SLUG
		);

		self::add_field( 'enable_datalayer_push', __( 'GA4 dataLayer Push', 'cleanclicks-wp' ), 'cleanclicks_behavior', 'render_field_checkbox', array(
			'label' => __( 'Push ecommerce events to window.dataLayer for GA4 real-time reports', 'cleanclicks-wp' ),
		) );

		self::add_field( 'debug', __( 'Debug Mode', 'cleanclicks-wp' ), 'cleanclicks_behavior', 'render_field_checkbox', array(
			'label' => __( 'Enable console logging ([CleanClicks] prefix)', 'cleanclicks-wp' ),
		) );

		// A4: purchase detection paths (only relevant when WC is loaded)
		if ( class_exists( 'WooCommerce' ) ) {
			add_settings_section(
				'cleanclicks_purchase_paths',
				esc_html__( 'Purchase Detection (Custom Thank-You Pages)', 'cleanclicks-wp' ),
				function () {
					echo '<p>' . esc_html__( 'CleanClicks captures purchases on the standard /order-received/ page automatically. Add additional paths here if your store redirects customers to custom thank-you URLs (subscription confirmations, membership signup pages, etc.).', 'cleanclicks-wp' ) . '</p>';
				},
				self::SLUG
			);

			self::add_field( 'purchase_paths', __( 'Custom Thank-You Paths', 'cleanclicks-wp' ), 'cleanclicks_purchase_paths', 'render_field_textarea', array(
				'placeholder' => "/thank-you/\n/order-confirmation/\n/my-account/view-subscription/",
				'description' => __( 'One path per line. Substring match against the request URL path. Defaults to standard WooCommerce confirmation URLs.', 'cleanclicks-wp' ),
				'rows'        => 5,
			) );

			self::add_field( 'purchase_path_regex', __( 'Custom Path Regex', 'cleanclicks-wp' ), 'cleanclicks_purchase_paths', 'render_field_text', array(
				'placeholder' => '^/scm-platinum-thanks/[0-9]+',
				'description' => __( 'Optional. PHP regex pattern (no delimiters) for advanced custom flows. Leave blank if you only need substring matches above.', 'cleanclicks-wp' ),
				'style'       => 'width:420px;',
			) );
		}
	}

	public static function render_field_textarea( $args ) {
		$s     = cleanclicks_settings();
		$key   = $args['key'];
		$raw   = $s[ $key ] ?? array();
		$value = is_array( $raw ) ? implode( "\n", $raw ) : (string) $raw;
		$name  = esc_attr( CLEANCLICKS_OPTION_KEY . '[' . $key . ']' );
		$ph    = isset( $args['placeholder'] ) ? esc_attr( $args['placeholder'] ) : '';
		$rows  = isset( $args['rows'] ) ? (int) $args['rows'] : 5;
		echo '<textarea id="' . esc_attr( $key ) . '" name="' . $name . '" rows="' . $rows . '" placeholder="' . $ph . '" style="width:420px;font-family:monospace;">' . esc_textarea( $value ) . '</textarea>';
		if ( ! empty( $args['description'] ) ) {
			echo '<p class="description">' . wp_kses_post( $args['description'] ) . '</p>';
		}
	}

	private static function add_field( $key, $title, $section, $callback, $extra = array() ) {
		$extra['key'] = $key;
		add_settings_field( $key, $title, array( __CLASS__, $callback ), self::SLUG, $section, $extra );
	}

	public static function render_field_text( $args ) {
		$s     = cleanclicks_settings();
		$key   = $args['key'];
		$value = esc_attr( (string) ( $s[ $key ] ?? '' ) );
		$name  = esc_attr( CLEANCLICKS_OPTION_KEY . '[' . $key . ']' );
		$ph    = isset( $args['placeholder'] ) ? esc_attr( $args['placeholder'] ) : '';
		$style = isset( $args['style'] ) ? esc_attr( $args['style'] ) : 'width:320px;';
		echo '<input type="text" id="' . esc_attr( $key ) . '" name="' . $name . '" value="' . $value . '" placeholder="' . $ph . '" style="' . $style . '" />';
		if ( ! empty( $args['description'] ) ) {
			echo '<p class="description">' . wp_kses_post( $args['description'] ) . '</p>';
		}
	}

	public static function render_field_checkbox( $args ) {
		$s       = cleanclicks_settings();
		$key     = $args['key'];
		$checked = ! empty( $s[ $key ] ) ? 'checked' : '';
		$name    = esc_attr( CLEANCLICKS_OPTION_KEY . '[' . $key . ']' );
		$label   = isset( $args['label'] ) ? esc_html( $args['label'] ) : '';
		echo '<label><input type="checkbox" name="' . $name . '" value="1" ' . $checked . ' /> ' . $label . '</label>';
	}

	public static function render_field_select( $args ) {
		$s       = cleanclicks_settings();
		$key     = $args['key'];
		$current = (string) ( $s[ $key ] ?? '' );
		$name    = esc_attr( CLEANCLICKS_OPTION_KEY . '[' . $key . ']' );
		$options = isset( $args['options'] ) ? $args['options'] : array();
		echo '<select name="' . $name . '" id="' . esc_attr( $key ) . '">';
		foreach ( $options as $val => $lbl ) {
			$sel = selected( $current, $val, false );
			echo '<option value="' . esc_attr( $val ) . '"' . $sel . '>' . esc_html( $lbl ) . '</option>';
		}
		echo '</select>';
		if ( ! empty( $args['description'] ) ) {
			echo '<p class="description">' . wp_kses_post( $args['description'] ) . '</p>';
		}
	}

	public static function sanitize( $input ) {
		$d   = cleanclicks_defaults();
		$out = array();

		// Phase 8.2c (v1.6.0): client_domain admin field removed. Preserve any
		// previously-saved value during settings updates so a pre-1.6.0 manual
		// override stays sacred until the customer explicitly clears it via DB or filter.
		$existing = get_option( CLEANCLICKS_OPTION_KEY, array() );
		if ( ! empty( $existing['client_domain'] ) ) {
			$out['client_domain'] = sanitize_text_field( $existing['client_domain'] );
		}
		$out['origin_override']    = esc_url_raw( trim( $input['origin_override'] ?? $d['origin_override'] ) );
		$out['ga4_measurement_id'] = preg_match( '/^G-[A-Z0-9]+$/', strtoupper( trim( $input['ga4_measurement_id'] ?? '' ) ) )
			? strtoupper( trim( $input['ga4_measurement_id'] ) )
			: $d['ga4_measurement_id'];
		$out['inbound_api_key']    = sanitize_text_field( $input['inbound_api_key'] ?? $d['inbound_api_key'] );
		$out['consent_category']   = in_array( $input['consent_category'] ?? '', array( 'statistics', 'statistics-anonymous', 'marketing' ), true )
			? $input['consent_category']
			: $d['consent_category'];

		$checkboxes = array( 'consent_required', 'enable_ga4_proxy', 'enable_usermaven_proxy', 'enable_plerdy_proxy', 'enable_datalayer_push', 'debug' );
		foreach ( $checkboxes as $cb ) {
			$out[ $cb ] = ! empty( $input[ $cb ] ) ? 1 : 0;
		}

		// A4: purchase_paths textarea → cleaned array; purchase_path_regex passes through raw.
		$paths_raw = $input['purchase_paths'] ?? '';
		if ( is_array( $paths_raw ) ) {
			$paths_raw = implode( "\n", $paths_raw );
		}
		$paths = array();
		foreach ( preg_split( '/\r\n|\r|\n/', (string) $paths_raw ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			// Keep only path-shaped values; drop any line containing protocol/host
			// to prevent accidental URL injection that wouldn't match REQUEST_URI anyway.
			if ( false !== strpos( $line, '://' ) ) {
				continue;
			}
			$paths[] = sanitize_text_field( $line );
		}
		$out['purchase_paths']      = ! empty( $paths ) ? $paths : $d['purchase_paths'];
		$out['purchase_path_regex'] = isset( $input['purchase_path_regex'] ) ? trim( (string) $input['purchase_path_regex'] ) : $d['purchase_path_regex'];

		delete_transient( CLEANCLICKS_CONFIG_TRANSIENT );

		// Schedule the credential fetch for after the settings save completes
		add_action('shutdown', function() { cleanclicks_fetch_usermaven_credentials(true); });

		return $out;
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$origin   = cleanclicks_origin();
		$domain   = cleanclicks_client_domain();
		$remote   = cleanclicks_remote_config();
		$has_woo  = class_exists( 'WooCommerce' );
		$settings = cleanclicks_settings();
		$api_key  = trim( (string) ( $settings['inbound_api_key'] ?? '' ) );

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'CleanClicks', 'cleanclicks-wp' ); ?></h1>

			<?php if ( '' === $api_key ) : ?>
				<?php self::render_onboarding_banner(); ?>
			<?php endif; ?>

			<?php self::render_status_card( $origin, $domain, $remote, $has_woo ); ?>

			<?php if ( $has_woo ) : ?>
				<?php self::render_webhook_status( $origin, $domain ); ?>
			<?php endif; ?>

			<form method="post" action="options.php">
				<?php
				settings_fields( self::GROUP );
				do_settings_sections( self::SLUG );
				submit_button();
				?>
			</form>
		</div>
		<?php
	}

	/**
	 * Onboarding banner shown when the API key is empty. Walks the
	 * customer through the one paste step that gates webhook auto-creation.
	 */
	private static function render_onboarding_banner() {
		?>
		<div class="cc-onboarding-banner" style="background:#fff8e5;border:1px solid #f0c33c;border-left:4px solid #f0b429;padding:14px 18px;margin:20px 0;max-width:860px;border-radius:4px;">
			<h2 style="margin:0 0 6px;font-size:18px;"><?php esc_html_e( "Welcome — one step to finish setup", 'cleanclicks-wp' ); ?></h2>
			<p style="margin:6px 0;">
				<?php esc_html_e( "CleanClicks needs your API key to auto-create the WooCommerce webhook that captures purchases. Paste it in the", 'cleanclicks-wp' ); ?>
				<strong><?php esc_html_e( 'Inbound API Key', 'cleanclicks-wp' ); ?></strong>
				<?php esc_html_e( 'field below, then save.', 'cleanclicks-wp' ); ?>
			</p>
			<p style="margin:6px 0;">
				<?php esc_html_e( 'Find your key in your CleanClicks dashboard:', 'cleanclicks-wp' ); ?>
				<a href="https://platform.cleanclicks.io/" target="_blank" rel="noopener noreferrer" class="button button-primary" style="margin-left:6px;">
					<?php esc_html_e( 'Open CleanClicks Dashboard', 'cleanclicks-wp' ); ?>
				</a>
			</p>
			<p style="margin:6px 0 0;color:#555;font-size:13px;">
				<?php esc_html_e( 'Once saved, the webhook is created automatically. No additional setup required.', 'cleanclicks-wp' ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Webhook status card — replaces the v1.5.1 manual setup instructions
	 * with a live state display + manual recreate button.
	 */
	private static function render_webhook_status( $origin, $domain ) {
		if ( ! class_exists( 'CleanClicks_Webhook_Manager' ) ) {
			return;
		}

		$status      = CleanClicks_Webhook_Manager::get_status();
		$exists      = ! empty( $status['exists'] );
		$wc_admin_url = admin_url( 'admin.php?page=wc-settings&tab=advanced&section=webhooks' );

		$reason_labels = array(
			'no_api_key'         => __( 'API key not configured. Save your inbound API key below to auto-create the webhook.', 'cleanclicks-wp' ),
			'wc_not_loaded'      => __( 'WooCommerce is not active.', 'cleanclicks-wp' ),
			'pending_creation'   => __( 'Webhook creation pending — will be created on the next page load.', 'cleanclicks-wp' ),
			'deleted_externally' => __( 'Webhook was deleted outside this plugin. Click Recreate to restore it.', 'cleanclicks-wp' ),
			'not_created'        => __( 'Webhook has not been created yet.', 'cleanclicks-wp' ),
		);

		$border_color = $exists ? '#39894b' : '#d63638';
		?>
		<div class="cc-webhook-card" style="background:#fff;border:1px solid #ccd0d4;border-left:4px solid <?php echo esc_attr( $border_color ); ?>;padding:12px 16px;margin:12px 0 20px;max-width:860px;">
			<h3 style="margin:0 0 8px;"><?php esc_html_e( 'WooCommerce Webhook Status', 'cleanclicks-wp' ); ?></h3>

			<?php if ( $exists ) : ?>
				<table class="widefat striped" style="max-width:100%;">
					<tr>
						<td style="width:180px;"><strong><?php esc_html_e( 'Status', 'cleanclicks-wp' ); ?></strong></td>
						<td>
							<?php if ( 'active' === $status['status'] ) : ?>
								<span style="color:#39894b;">&#10003; <?php echo esc_html( ucfirst( $status['status'] ) ); ?></span>
							<?php else : ?>
								<span style="color:#d63638;"><?php echo esc_html( ucfirst( $status['status'] ) ); ?></span>
							<?php endif; ?>
						</td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Webhook ID', 'cleanclicks-wp' ); ?></strong></td>
						<td><code><?php echo esc_html( $status['id'] ); ?></code></td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Topic', 'cleanclicks-wp' ); ?></strong></td>
						<td><code><?php echo esc_html( $status['topic'] ); ?></code></td>
					</tr>
					<tr>
						<td><strong><?php esc_html_e( 'Delivery URL', 'cleanclicks-wp' ); ?></strong></td>
						<td><code style="font-size:12px;"><?php echo esc_html( $status['delivery_url'] ); ?></code></td>
					</tr>
				</table>
				<p style="margin-top:12px;">
					<button type="button" class="button cc-recreate-webhook"><?php esc_html_e( 'Recreate Webhook', 'cleanclicks-wp' ); ?></button>
					<a href="<?php echo esc_url( $wc_admin_url ); ?>" class="button" target="_blank" rel="noopener"><?php esc_html_e( 'View in WooCommerce', 'cleanclicks-wp' ); ?> &rarr;</a>
					<span class="cc-recreate-status" style="margin-left:10px;"></span>
				</p>
			<?php else : ?>
				<p style="margin:0 0 8px;">
					<span style="color:#d63638;font-weight:600;"><?php esc_html_e( 'Webhook not active', 'cleanclicks-wp' ); ?></span>
					<?php
					$reason_key   = $status['reason_missing'] ?? 'not_created';
					$reason_text  = $reason_labels[ $reason_key ] ?? $reason_labels['not_created'];
					echo ' — ' . esc_html( $reason_text );
					?>
				</p>
				<?php if ( ! empty( $status['last_error'] ) ) : ?>
					<p style="color:#d63638;font-size:13px;"><strong><?php esc_html_e( 'Last error:', 'cleanclicks-wp' ); ?></strong> <?php echo esc_html( $status['last_error'] ); ?></p>
				<?php endif; ?>
				<p>
					<?php
					$can_create = isset( $status['reason_missing'] ) && in_array( $status['reason_missing'], array( 'not_created', 'deleted_externally', 'pending_creation' ), true );
					?>
					<button type="button" class="button button-primary cc-recreate-webhook" <?php disabled( ! $can_create ); ?>>
						<?php esc_html_e( 'Create Webhook Now', 'cleanclicks-wp' ); ?>
					</button>
					<a href="<?php echo esc_url( $wc_admin_url ); ?>" class="button" target="_blank" rel="noopener"><?php esc_html_e( 'View in WooCommerce', 'cleanclicks-wp' ); ?> &rarr;</a>
					<span class="cc-recreate-status" style="margin-left:10px;"></span>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	private static function render_status_card( $origin, $domain, $remote, $has_woo ) {
		$connected = ! empty( $remote );
		?>
		<div id="cc-status-card" class="cc-status-card" style="background:#fff;border:1px solid #ccd0d4;border-left:4px solid <?php echo $connected ? '#39894b' : '#d63638'; ?>;padding:12px 16px;margin:12px 0 20px;max-width:700px;">
			<h3 style="margin:0 0 8px;"><?php esc_html_e( 'Connection Status', 'cleanclicks-wp' ); ?></h3>
			<table class="widefat striped" style="max-width:100%;">
				<tr>
					<td style="width:180px;"><strong><?php esc_html_e( 'Domain', 'cleanclicks-wp' ); ?></strong></td>
					<td><code><?php echo esc_html( $domain ?: '(not set)' ); ?></code></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Proxy Origin', 'cleanclicks-wp' ); ?></strong></td>
					<td><code><?php echo esc_html( $origin ?: '(not set)' ); ?></code></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Remote Config', 'cleanclicks-wp' ); ?></strong></td>
					<td>
						<?php if ( $connected ) : ?>
							<span id="cc-conn-status" style="color:#39894b;">&
						<?php else : ?>
							<span id="cc-conn-status" style="color:#d63638;">&
						<?php endif; ?>
						<button type="button" class="button button-small" id="cc-test-connection" style="margin-left:8px;">
							<?php esc_html_e( 'Test Connection', 'cleanclicks-wp' ); ?>
						</button>
						<span id="cc-test-result" style="margin-left:8px;"></span>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'WooCommerce', 'cleanclicks-wp' ); ?></strong></td>
					<td>
						<?php if ( $has_woo ) : ?>
							<span style="color:#39894b;">&
						<?php else : ?>
							<span style="color:#72777c;"><?php esc_html_e( 'Not installed — lead tracking mode', 'cleanclicks-wp' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
				<?php if ( $connected && ! empty( $remote['vendors'] ) ) : ?>
				<tr>
					<td><strong><?php esc_html_e( 'Active Vendors', 'cleanclicks-wp' ); ?></strong></td>
					<td>
						<?php
						$names = array(
							'googleads'    => 'Google Ads',
							'meta'         => 'Meta',
							'tiktok'       => 'TikTok',
							'linkedin'     => 'LinkedIn',
							'microsoftads' => 'Microsoft Ads',
							'ga4'          => 'GA4',
						);
						$active = array();
						foreach ( $remote['vendors'] as $k => $v ) {
							if ( $v && isset( $names[ $k ] ) ) {
								$active[] = $names[ $k ];
							}
						}
						echo esc_html( $active ? implode( ', ', $active ) : 'None' );
						?>
					</td>
				</tr>
				<?php endif; ?>
			</table>
		</div>
		<?php
	}

	// Note: v1.5.1's render_webhook_instructions() (manual setup walkthrough) was
	// removed in v1.5.2 — webhook is now auto-created by CleanClicks_Webhook_Manager.
	// See render_webhook_status() above for the live state surface.

	public static function enqueue_admin_assets( $hook ) {

		$toplevel_page = 'toplevel_page_' . self::SLUG;
		if ( $hook !== $toplevel_page ) {
			return;
		}

		wp_enqueue_style(
			'cleanclicks-admin',
			CLEANCLICKS_PLUGIN_URL . 'assets/css/cc-admin.css',
			array(),
			CLEANCLICKS_VERSION
		);

		wp_enqueue_script(
			'cleanclicks-admin',
			CLEANCLICKS_PLUGIN_URL . 'assets/js/cc-admin.js',
			array(),
			CLEANCLICKS_VERSION,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);

		wp_localize_script( 'cleanclicks-admin', 'ccAdmin', array(
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce'   => wp_create_nonce( 'cleanclicks_admin' ),
		) );
	}

	public static function ajax_test_connection() {
		check_ajax_referer( 'cleanclicks_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			wp_send_json_error( 'No origin configured' );
		}

		$cc_js = wp_remote_get( $origin . '/__cc/cc.js', array(
			'timeout'    => 10,
			'user-agent' => 'CleanClicks-WP/' . CLEANCLICKS_VERSION . ' (+' . home_url( '/' ) . ')',
		) );
		$cc_ok = ! is_wp_error( $cc_js ) && wp_remote_retrieve_response_code( $cc_js ) === 200;

		$config = cleanclicks_remote_config( true );
		$cfg_ok = ! empty( $config );

		$um_ok = cleanclicks_fetch_usermaven_credentials( true );

		$results = array(
			'cc_js'     => $cc_ok,
			'config'    => $cfg_ok,
			'origin'    => $origin,
			'usermaven' => $um_ok,
		);

		if ( $cc_ok && $cfg_ok ) {
			wp_send_json_success( $results );
		} else {
			wp_send_json_error( $results );
		}
	}

	public static function maybe_show_backfill_notice() {
		if ( get_option( 'cleanclicks_usermaven_backfill_complete', '' ) === '1' ) {
			return;
		}
		$offset = (int) get_option( 'cleanclicks_usermaven_backfill_offset', 0 );
		if ( $offset <= 0 ) {
			return;
		}
		$total = (int) get_option( 'cleanclicks_usermaven_backfill_total', 0 );
		if ( $total <= 0 ) {
			return;
		}
		$current = min( $offset, $total );
		echo '<div class="notice notice-info"><p>';
		echo '<strong>CleanClicks:</strong> Syncing historical orders to Usermaven&hellip; ';
		echo esc_html( $current ) . ' of ' . esc_html( $total ) . ' orders processed.';
		echo '</p></div>';
	}

	public static function ajax_refresh_config() {
		check_ajax_referer( 'cleanclicks_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Unauthorized' );
		}

		$config = cleanclicks_remote_config( true );
		if ( ! empty( $config ) ) {
			wp_send_json_success( $config );
		} else {
			wp_send_json_error( 'Could not fetch remote config' );
		}
	}

	/**
	 * A5: AJAX handler for the "Recreate Webhook" button.
	 * Calls CleanClicks_Webhook_Manager::create_webhook() (idempotent: it
	 * deletes any existing tracked webhook before creating the new one).
	 */
	public static function ajax_recreate_webhook() {
		check_ajax_referer( 'cleanclicks_admin', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Unauthorized', 'cleanclicks-wp' ) ), 403 );
		}

		if ( ! class_exists( 'CleanClicks_Webhook_Manager' ) ) {
			wp_send_json_error( array( 'message' => __( 'Webhook manager not available.', 'cleanclicks-wp' ) ), 500 );
		}

		$result = CleanClicks_Webhook_Manager::create_webhook();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array(
				'message' => $result->get_error_message(),
				'code'    => $result->get_error_code(),
			), 400 );
		}

		$status = CleanClicks_Webhook_Manager::get_status();
		wp_send_json_success( array(
			'message' => __( 'Webhook created successfully.', 'cleanclicks-wp' ),
			'status'  => $status,
		) );
	}
}
