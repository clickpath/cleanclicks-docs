<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_Proxies {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'inject_proxy_scripts' ), 5 );

		add_action( 'wp_head', array( __CLASS__, 'inject_usermaven_head' ), 99 );
		add_action( 'wp_head', array( __CLASS__, 'inject_plerdy_head' ), 99 );
	}

	private static function has_consent() {
		$s = cleanclicks_settings();
		if ( ! empty( $s['consent_required'] ) ) {
			$cat = $s['consent_category'] ?? 'statistics';
			// D2-NEW-4: cleanclicks_has_consent_for() prefers service-level consent
			// (WP Consent API v2.0+) over category-level (v1.x). Returns true when
			// no Consent API is loaded — outer consent_required toggle is the gate.
			if ( function_exists( 'cleanclicks_has_consent_for' ) && ! cleanclicks_has_consent_for( $cat ) ) {
				return false;
			}
		}
		return true;
	}

	public static function inject_proxy_scripts() {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
			return;
		}
		if ( ! self::has_consent() ) {
			return;
		}

		$origin   = cleanclicks_origin();
		if ( ! $origin ) {
			return;
		}

		$settings = cleanclicks_settings();
		$remote   = cleanclicks_remote_config();
		$proxies  = isset( $remote['proxies'] ) ? $remote['proxies'] : array();

		if ( ! empty( $settings['enable_ga4_proxy'] ) ) {
			self::inject_ga4_proxy( $origin, $settings, $proxies );
		}

		if ( ! empty( $settings['enable_usermaven_proxy'] ) ) {
			self::inject_usermaven_proxy( $origin, $proxies );
		}

		if ( ! empty( $settings['enable_plerdy_proxy'] ) ) {
			self::inject_plerdy_proxy( $origin, $proxies );
		}
	}

	private static function inject_ga4_proxy( $origin, $settings, $proxies ) {

		$mid = trim( $settings['ga4_measurement_id'] ?? '' );
		if ( ! $mid && ! empty( $proxies['ga4']['measurementId'] ) ) {
			$mid = $proxies['ga4']['measurementId'];
		}
		if ( ! $mid ) {
			return;
		}

		$proxy_base = $origin . '/__cc/g';

		wp_enqueue_script(
			'cleanclicks-gtag',
			$proxy_base . '/gtag/js?id=' . rawurlencode( $mid ) . '&l=ccDataLayer',
			array(),
			null,
			array( 'strategy' => 'async', 'in_footer' => false )
		);

		$allow_signals = ! empty( $proxies['ga4']['allowSignals'] );
		$config_obj    = $allow_signals
			? '{}'
			: '{server_container_url:' . wp_json_encode( $proxy_base ) . '}';
		$inline = "window.ccDataLayer=window.ccDataLayer||[];"
			. "function ccGtag(){ccDataLayer.push(arguments);}window.ccGtag=ccGtag;"
			. "ccGtag('js',new Date());"
			. "ccGtag('config'," . wp_json_encode( $mid ) . "," . $config_obj . ");";

		wp_add_inline_script( 'cleanclicks-gtag', $inline, 'after' );
	}

	private static function inject_usermaven_proxy( $origin, $proxies ) {

		$um = isset( $proxies['usermaven'] ) ? $proxies['usermaven'] : array();
		if ( empty( $um['enabled'] ) || empty( $um['accountToken'] ) ) {
			return;
		}

		self::$usermaven_config = array(
			'origin' => $origin,
			'token'  => $um['accountToken'],
		);
	}

	private static $usermaven_config = null;

	public static function inject_usermaven_head() {
		if ( ! self::$usermaven_config ) {
			return;
		}
		$um_key = self::$usermaven_config['token'];
		if ( ! preg_match( '/^[A-Za-z0-9_\-]+$/', $um_key ) ) {
			return;
		}
		$proxy_base = self::$usermaven_config['origin'] . '/__cc/p';
		$token      = wp_json_encode( $um_key );
		$track_host = wp_json_encode( $proxy_base . '/usermaven-events' );
		$lib_src    = wp_json_encode( $proxy_base . '/usermaven/lib.js' );
		?>
		<script id="cleanclicks-usermaven">
		(function(){
			window.usermaven=window.usermaven||function(){(window.usermavenQ=window.usermavenQ||[]).push(arguments);};
			var t=document.createElement('script'),s=document.getElementsByTagName('script')[0];
			t.defer=true;t.id='um-tracker';
			t.setAttribute('data-tracking-host',<?php echo $track_host; ?>);
			t.setAttribute('data-key',<?php echo $token; ?>);
			t.setAttribute('data-autocapture','true');
			t.setAttribute('data-auto-pageview','true');
			t.setAttribute('data-form-tracking','all');
			t.src=<?php echo $lib_src; ?>;
			s.parentNode.insertBefore(t,s);
		})();
		</script>
		<?php
	}

	private static function inject_plerdy_proxy( $origin, $proxies ) {
		$pl = isset( $proxies['plerdy'] ) ? $proxies['plerdy'] : array();
		if ( empty( $pl['enabled'] ) || empty( $pl['accountToken'] ) ) {
			return;
		}
		self::$plerdy_config = array(
			'origin'       => $origin,
			'accountToken' => $pl['accountToken'],
			'accountId'    => $pl['accountId'] ?? '0',
		);
	}

	private static $plerdy_config = null;

	public static function inject_plerdy_head() {
		if ( ! self::$plerdy_config ) {
			return;
		}
		$proxy_base = self::$plerdy_config['origin'] . '/__cc/p';
		$site_hash  = wp_json_encode( self::$plerdy_config['accountToken'] );
		$uid        = intval( self::$plerdy_config['accountId'] );
		$script_url = wp_json_encode( $proxy_base . '/plerdy/public/js/click/main.js' );
		?>
		<script id="cleanclicks-plerdy">
		var _protocol="https:";
		var _site_hash_code=<?php echo $site_hash; ?>;
		var _suid=<?php echo $uid; ?>;
		var plerdyScript=document.createElement("script");
		plerdyScript.setAttribute("defer","");
		plerdyScript.dataset.plerdymainscript="plerdymainscript";
		plerdyScript.src=<?php echo $script_url; ?>+"?v="+Math.random();
		var plerdymainscript=document.querySelector("[data-plerdymainscript='plerdymainscript']");
		if(plerdymainscript)plerdymainscript.parentNode.removeChild(plerdymainscript);
		try{document.head.appendChild(plerdyScript);}catch(t){console.log(t,"unable to add script tag");}
		</script>
		<?php
	}
}
