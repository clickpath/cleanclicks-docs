<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_Tracker {

	public static function init() {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_scripts' ), 10 );
		add_action( 'wp_head', array( __CLASS__, 'inject_ping' ), 1 );
		add_action( 'wp_head', array( __CLASS__, 'inject_ccwp_config' ), 2 );

		add_filter( 'rocket_delay_js_exclusions', array( __CLASS__, 'rocket_exclude_scripts' ) );
		add_filter( 'rocket_exclude_defer_js', array( __CLASS__, 'rocket_exclude_scripts' ) );
		add_filter( 'rocket_minify_excluded_external_js', array( __CLASS__, 'rocket_exclude_external' ) );
	}

	public static function rocket_exclude_scripts( $excluded ) {
		$excluded[] = '/__cc/cc.js';
		$excluded[] = 'cleanclicks-wp/assets/js/cc-wp.js';
		return $excluded;
	}

	public static function rocket_exclude_external( $excluded ) {
		$excluded[] = '/__cc/cc.js';
		return $excluded;
	}

	public static function inject_ping() {
		if ( ! self::should_track() ) {
			return;
		}
		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			return;
		}
		echo '<script>fetch(' . wp_json_encode( $origin . '/__cc/ping' ) . ',{method:"POST",keepalive:true})</script>' . "\n";
	}

	public static function inject_ccwp_config() {
		if ( ! self::should_track() ) {
			return;
		}
		$origin   = cleanclicks_origin();
		$domain   = cleanclicks_client_domain();
		$settings = cleanclicks_settings();
		$remote   = cleanclicks_remote_config();
		$runtime  = self::build_runtime_config( $origin, $domain, $settings, $remote );
		echo '<script>window.__ccwp=' . wp_json_encode( $runtime ) . ';</script>' . "\n";
	}

	private static function should_track() {
		$origin = cleanclicks_origin();
		if ( ! $origin ) {
			return false;
		}

		$s = cleanclicks_settings();
		if ( ! empty( $s['consent_required'] ) ) {
			$category = $s['consent_category'] ?? 'statistics';
			// D2-NEW-4: cleanclicks_has_consent_for() prefers service-level consent
			// (WP Consent API v2.0+) over category-level (v1.x). Returns true when
			// no Consent API is loaded — outer consent_required toggle is the gate then.
			if ( function_exists( 'cleanclicks_has_consent_for' ) && ! cleanclicks_has_consent_for( $category ) ) {
				return false;
			}
		}

		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || defined( 'REST_REQUEST' ) ) {
			return false;
		}

		return true;
	}

	public static function enqueue_scripts() {
		if ( ! self::should_track() ) {
			return;
		}

		$origin   = cleanclicks_origin();
		$domain   = cleanclicks_client_domain();
		$settings = cleanclicks_settings();
		$remote   = cleanclicks_remote_config();

		wp_enqueue_script(
			'cleanclicks-cc-js',
			$origin . '/__cc/cc.js',
			array(),
			null,
			array( 'strategy' => 'async', 'in_footer' => false )
		);

		wp_enqueue_script(
			'cleanclicks-wp',
			CLEANCLICKS_PLUGIN_URL . 'assets/js/cc-wp.js',
			array(),
			CLEANCLICKS_VERSION,
			array( 'strategy' => 'defer', 'in_footer' => true )
		);
	}

	private static function build_runtime_config( $origin, $domain, $settings, $remote ) {
		$tag_config = isset( $remote['tagConfig'] ) ? $remote['tagConfig'] : array();

		$ga4_mid = trim( $settings['ga4_measurement_id'] ?? '' );
		if ( ! $ga4_mid ) {
			$proxies = isset( $remote['proxies'] ) ? $remote['proxies'] : array();
			if ( ! empty( $proxies['ga4']['measurementId'] ) ) {
				$ga4_mid = $proxies['ga4']['measurementId'];
			}
		}

		$config = array(
			'origin'          => $origin,
			'domain'          => $domain,
			'debug'           => ! empty( $settings['debug'] ),
			'dataLayerPush'   => ! empty( $settings['enable_datalayer_push'] ),
			'ga4MeasurementId' => $ga4_mid ?: null,
			'consentRequired' => ! empty( $settings['consent_required'] ),
			'consentCategory' => $settings['consent_category'] ?? 'statistics',
			'source'          => 'wordpress_plugin',

			'captureQueryParams' => $tag_config['captureQueryParams']
				?? array( 'gclid', 'wbraid', 'gbraid', 'fbclid', 'ttclid', 'tbclid', 'li_fat_id', 'msclkid' ),
			'dedupeWindowSeconds' => $tag_config['dedupeWindowSeconds'] ?? 86400,

			'hasWoo'   => class_exists( 'WooCommerce' ),
			'currency' => function_exists( 'get_woocommerce_currency' ) ? get_woocommerce_currency() : 'USD',
		);

		return $config;
	}
}
