<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Manages the WooCommerce webhook that delivers order events to the
 * CleanClicks tracking proxy. Auto-created on plugin activation when
 * an API key is configured, removed on deactivation, and recreated
 * whenever the API key changes via settings save.
 *
 * Delivery URL: https://cleanclicks.<domain>/__cc/woocommerce/webhook
 * Webhook secret = customer's inbound_api_key (one key, two jobs).
 * Topic: order.created (server-side payment_complete hook is the
 *        backstop for subscription renewals + custom thank-you flows).
 */
class CleanClicks_Webhook_Manager {

	const WEBHOOK_NAME          = 'CleanClicks Conversion Capture';
	const WEBHOOK_TOPIC         = 'order.created';
	const OPTION_WEBHOOK_ID     = 'cleanclicks_webhook_id';
	const OPTION_PENDING_CREATE = 'cleanclicks_webhook_pending_create';
	const OPTION_LAST_ERROR     = 'cleanclicks_webhook_last_error';

	public static function init() {
		// Deferred creation runs after WC loads in the request lifecycle.
		add_action( 'woocommerce_init', array( __CLASS__, 'maybe_create_pending' ), 100 );

		// Re-attempt on settings save (handles "activate then paste API key" flow).
		add_action( 'update_option_' . CLEANCLICKS_OPTION_KEY, array( __CLASS__, 'on_settings_save' ), 10, 2 );
	}

	/**
	 * Plugin activation handler. Flag for deferred creation.
	 * Cannot create the webhook here directly: register_activation_hook
	 * runs in a special context where many hooks haven't fired yet and
	 * WC may not be available.
	 */
	public static function on_plugin_activation() {
		update_option( self::OPTION_PENDING_CREATE, '1' );
	}

	/**
	 * Plugin deactivation handler. Runs in the normal request lifecycle
	 * so WC is loaded if it was active.
	 */
	public static function on_plugin_deactivation() {
		self::delete_webhook();
		delete_option( self::OPTION_PENDING_CREATE );
		delete_option( self::OPTION_LAST_ERROR );
	}

	/**
	 * Settings-save handler. Reacts to changes in inbound_api_key:
	 *  - empty → set     : create the webhook
	 *  - set   → empty   : delete the webhook
	 *  - changed         : delete + recreate with new secret
	 */
	public static function on_settings_save( $old_value, $new_value ) {
		$old_value = is_array( $old_value ) ? $old_value : array();
		$new_value = is_array( $new_value ) ? $new_value : array();

		$old_key = isset( $old_value['inbound_api_key'] ) ? trim( (string) $old_value['inbound_api_key'] ) : '';
		$new_key = isset( $new_value['inbound_api_key'] ) ? trim( (string) $new_value['inbound_api_key'] ) : '';

		if ( $old_key === $new_key ) {
			return;
		}

		if ( '' === $new_key ) {
			self::delete_webhook();
			return;
		}

		// Either empty→set or set→changed — both cases create with the new key.
		self::delete_webhook();
		self::create_webhook();
	}

	/**
	 * Hooked to woocommerce_init. If activation flagged a pending
	 * creation, attempt it now. Leaves the pending flag in place if
	 * creation fails (e.g., API key not yet configured), so a future
	 * page load can retry.
	 */
	public static function maybe_create_pending() {
		if ( '1' !== get_option( self::OPTION_PENDING_CREATE, '' ) ) {
			return;
		}

		$result = self::create_webhook();
		if ( is_wp_error( $result ) ) {
			// Retain pending flag for a future retry.
			return;
		}

		delete_option( self::OPTION_PENDING_CREATE );
	}

	/**
	 * Create the webhook. Returns int webhook ID on success or WP_Error.
	 * Idempotent: deletes any existing tracked webhook first to keep
	 * a clean 1:1 relationship between this plugin and a WC webhook row.
	 */
	public static function create_webhook() {
		if ( ! class_exists( 'WC_Webhook' ) ) {
			$err = new WP_Error( 'wc_not_loaded', __( 'WooCommerce is not active.', 'cleanclicks-wp' ) );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		$settings = cleanclicks_settings();
		$api_key  = isset( $settings['inbound_api_key'] ) ? trim( (string) $settings['inbound_api_key'] ) : '';
		if ( '' === $api_key ) {
			$err = new WP_Error( 'no_api_key', __( 'CleanClicks API key not configured.', 'cleanclicks-wp' ) );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		$origin = cleanclicks_origin();
		if ( empty( $origin ) ) {
			$err = new WP_Error( 'no_origin', __( 'CleanClicks origin not derivable.', 'cleanclicks-wp' ) );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		$delivery_url = $origin . '/__cc/woocommerce/webhook';

		// Idempotency: any tracked existing webhook gets removed before we create the new one.
		self::delete_webhook();

		$user_id = self::pick_user_id();
		if ( ! $user_id ) {
			$err = new WP_Error( 'no_user', __( 'No administrator user available for webhook authorship.', 'cleanclicks-wp' ) );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		try {
			$webhook = new WC_Webhook();
			$webhook->set_user_id( $user_id );
			$webhook->set_topic( self::WEBHOOK_TOPIC );
			$webhook->set_delivery_url( $delivery_url );
			$webhook->set_secret( $api_key );
			$webhook->set_status( 'active' );
			$webhook->set_name( self::WEBHOOK_NAME );
			$webhook->set_api_version( wc_get_webhook_rest_api_versions()[0] ?? 'wp_api_v3' );
			$webhook->save();
		} catch ( Exception $e ) {
			$err = new WP_Error( 'create_failed', $e->getMessage() );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		$webhook_id = (int) $webhook->get_id();
		if ( ! $webhook_id ) {
			$err = new WP_Error( 'create_failed', __( 'WC_Webhook->save() returned no ID.', 'cleanclicks-wp' ) );
			update_option( self::OPTION_LAST_ERROR, $err->get_error_message() );
			return $err;
		}

		update_option( self::OPTION_WEBHOOK_ID, $webhook_id );
		delete_option( self::OPTION_LAST_ERROR );
		return $webhook_id;
	}

	/**
	 * Delete the tracked webhook if it still exists. Safe to call when
	 * no webhook is tracked. Always clears the option.
	 */
	public static function delete_webhook() {
		$webhook_id = (int) get_option( self::OPTION_WEBHOOK_ID, 0 );
		if ( ! $webhook_id ) {
			return;
		}

		if ( function_exists( 'wc_get_webhook' ) ) {
			$webhook = wc_get_webhook( $webhook_id );
			if ( $webhook ) {
				try {
					$webhook->delete( true );
				} catch ( Exception $e ) {
					// Stale option will fall through; UI status check will report deleted_externally.
				}
			}
		}

		delete_option( self::OPTION_WEBHOOK_ID );
	}

	/**
	 * Status query for admin UI (A5) and external diagnostics.
	 * Returns an associative array describing current webhook state.
	 */
	public static function get_status() {
		$webhook_id = (int) get_option( self::OPTION_WEBHOOK_ID, 0 );
		$settings   = cleanclicks_settings();
		$api_key    = isset( $settings['inbound_api_key'] ) ? trim( (string) $settings['inbound_api_key'] ) : '';
		$last_error = (string) get_option( self::OPTION_LAST_ERROR, '' );

		// No tracked webhook → describe why.
		if ( ! $webhook_id ) {
			$reason = 'not_created';
			if ( '' === $api_key ) {
				$reason = 'no_api_key';
			} elseif ( ! class_exists( 'WC_Webhook' ) ) {
				$reason = 'wc_not_loaded';
			} elseif ( '1' === get_option( self::OPTION_PENDING_CREATE, '' ) ) {
				$reason = 'pending_creation';
			}
			return array(
				'exists'         => false,
				'id'             => 0,
				'reason_missing' => $reason,
				'last_error'     => $last_error,
			);
		}

		if ( ! function_exists( 'wc_get_webhook' ) ) {
			return array(
				'exists'         => false,
				'id'             => $webhook_id,
				'reason_missing' => 'wc_not_loaded',
				'last_error'     => $last_error,
			);
		}

		$webhook = wc_get_webhook( $webhook_id );
		if ( ! $webhook ) {
			delete_option( self::OPTION_WEBHOOK_ID );
			return array(
				'exists'         => false,
				'id'             => 0,
				'reason_missing' => 'deleted_externally',
				'last_error'     => $last_error,
			);
		}

		return array(
			'exists'       => true,
			'id'           => (int) $webhook->get_id(),
			'name'         => $webhook->get_name(),
			'status'       => $webhook->get_status(),
			'topic'        => $webhook->get_topic(),
			'delivery_url' => $webhook->get_delivery_url(),
			'api_version'  => $webhook->get_api_version(),
			'last_error'   => $last_error,
		);
	}

	/**
	 * Pick a user ID with manage_woocommerce capability for webhook
	 * authorship. WC_Webhook requires this; deliveries are filtered
	 * server-side by what the user can read.
	 */
	private static function pick_user_id() {
		$current = get_current_user_id();
		if ( $current && user_can( $current, 'manage_woocommerce' ) ) {
			return (int) $current;
		}

		$admins = get_users( array(
			'role'   => 'administrator',
			'number' => 1,
			'fields' => 'ID',
		) );

		return ! empty( $admins ) ? (int) $admins[0] : 0;
	}
}

CleanClicks_Webhook_Manager::init();
