<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_Privacy {

	public static function init() {

		add_action( 'admin_init', array( __CLASS__, 'add_privacy_policy_content' ) );

		add_filter( 'wp_privacy_personal_data_exporters', array( __CLASS__, 'register_exporter' ) );

		add_filter( 'wp_privacy_personal_data_erasers', array( __CLASS__, 'register_eraser' ) );

		add_action( 'init', array( __CLASS__, 'register_cookies' ) );
	}

	public static function add_privacy_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content = '<h2>' . esc_html__( 'CleanClicks Conversion Tracking', 'cleanclicks-wp' ) . '</h2>'
			. '<p>' . esc_html__( 'This website uses CleanClicks, a first-party conversion tracking system. CleanClicks collects the following data to measure advertising effectiveness:', 'cleanclicks-wp' ) . '</p>'
			. '<ul>'
			. '<li>' . esc_html__( 'Page views and conversion events (form submissions, purchases)', 'cleanclicks-wp' ) . '</li>'
			. '<li>' . esc_html__( 'Advertising click identifiers (gclid, fbclid, etc.) from URL parameters', 'cleanclicks-wp' ) . '</li>'
			. '<li>' . esc_html__( 'UTM campaign parameters and referring website', 'cleanclicks-wp' ) . '</li>'
			. '<li>' . esc_html__( 'Browser session data (session ID, page title, screen resolution, language)', 'cleanclicks-wp' ) . '</li>'
			. '<li>' . esc_html__( 'One-way hashed email address (SHA-256, irreversible) for purchase attribution', 'cleanclicks-wp' ) . '</li>'
			. '</ul>'
			. '<p>' . esc_html__( 'All tracking data is transmitted to a first-party subdomain on this website (not a third-party server). If you have configured vendor integrations (Google Ads, Meta, TikTok, LinkedIn, Microsoft Ads, GA4), conversion data may be forwarded to those platforms for advertising optimization.', 'cleanclicks-wp' ) . '</p>'
			. '<p>' . esc_html__( 'CleanClicks respects the Global Privacy Control (GPC) browser signal. When GPC is detected, tracking switches to limited data use mode and compliant vendor flags are applied.', 'cleanclicks-wp' ) . '</p>'
			. '<p>' . wp_kses_post( __( 'If a consent management plugin is installed, CleanClicks will not load tracking scripts until consent is granted (when "Require Consent" is enabled in settings).', 'cleanclicks-wp' ) ) . '</p>'
			. '<p>' . esc_html__( 'Tracking data is retained for 90 days on the CleanClicks server and automatically purged thereafter.', 'cleanclicks-wp' ) . '</p>';

		wp_add_privacy_policy_content(
			'CleanClicks',
			wp_kses_post( $content )
		);
	}

	public static function register_exporter( $exporters ) {
		$exporters['cleanclicks'] = array(
			'exporter_friendly_name' => esc_html__( 'CleanClicks Tracking Data', 'cleanclicks-wp' ),
			'callback'               => array( __CLASS__, 'export_personal_data' ),
		);
		return $exporters;
	}

	public static function export_personal_data( $email, $page = 1 ) {
		$data = array();

		$data[] = array(
			'group_id'          => 'cleanclicks',
			'group_label'       => esc_html__( 'CleanClicks Tracking', 'cleanclicks-wp' ),
			'group_description' => esc_html__( 'Conversion tracking data collected by CleanClicks.', 'cleanclicks-wp' ),
			'item_id'           => 'cleanclicks-info',
			'data'              => array(
				array(
					'name'  => esc_html__( 'Email Hash (SHA-256)', 'cleanclicks-wp' ),
					'value' => hash( 'sha256', strtolower( trim( $email ) ) ),
				),
				array(
					'name'  => esc_html__( 'Data Location', 'cleanclicks-wp' ),
					'value' => esc_html__( 'Conversion events are stored on your CleanClicks server (first-party subdomain) with a 90-day retention period.', 'cleanclicks-wp' ),
				),
				array(
					'name'  => esc_html__( 'Local Storage', 'cleanclicks-wp' ),
					'value' => esc_html__( 'Click IDs, attribution data, and session info stored in browser localStorage/sessionStorage under cc_* keys.', 'cleanclicks-wp' ),
				),
			),
		);

		return array(
			'data' => $data,
			'done' => true,
		);
	}

	public static function register_eraser( $erasers ) {
		$erasers['cleanclicks'] = array(
			'eraser_friendly_name' => esc_html__( 'CleanClicks Tracking Data', 'cleanclicks-wp' ),
			'callback'             => array( __CLASS__, 'erase_personal_data' ),
		);
		return $erasers;
	}

	public static function erase_personal_data( $email, $page = 1 ) {
		return array(
			'items_removed'  => false,
			'items_retained' => true,
			'messages'       => array(
				esc_html__( 'CleanClicks stores conversion data on the tracking server (first-party subdomain) using one-way hashed emails. This data auto-expires after 90 days. Browser-stored tracking cookies (cc_* keys) will be cleared when the user clears their browser data.', 'cleanclicks-wp' ),
			),
			'done'           => true,
		);
	}

	public static function register_cookies() {
		if ( ! function_exists( 'wp_add_cookie_info' ) ) {
			return;
		}

		wp_add_cookie_info(
			'cc_pid',
			'CleanClicks',
			'persistent',
			__( '1 year', 'cleanclicks-wp' ),
			__( 'functional', 'cleanclicks-wp' ),
			__( 'Anonymous visitor identifier for conversion deduplication.', 'cleanclicks-wp' )
		);

		wp_add_cookie_info(
			'cc_click_ids (sessionStorage)',
			'CleanClicks',
			'session',
			__( 'Session', 'cleanclicks-wp' ),
			__( 'functional', 'cleanclicks-wp' ),
			__( 'Advertising click identifiers captured from URL parameters.', 'cleanclicks-wp' )
		);

		wp_add_cookie_info(
			'cc_attribution (localStorage)',
			'CleanClicks',
			'persistent',
			__( '30 days', 'cleanclicks-wp' ),
			__( 'functional', 'cleanclicks-wp' ),
			__( 'UTM campaign parameters, referrer, and landing page for attribution.', 'cleanclicks-wp' )
		);

		wp_add_cookie_info(
			'cc_session_id (sessionStorage)',
			'CleanClicks',
			'session',
			__( 'Session', 'cleanclicks-wp' ),
			__( 'functional', 'cleanclicks-wp' ),
			__( 'Session identifier for grouping page views within a visit.', 'cleanclicks-wp' )
		);

		wp_add_cookie_info(
			'cc_ss_optout',
			'CleanClicks',
			'persistent',
			__( '1 year', 'cleanclicks-wp' ),
			__( 'functional', 'cleanclicks-wp' ),
			__( 'Privacy opt-out flag. When set, tracking switches to limited data use mode.', 'cleanclicks-wp' )
		);
	}
}
