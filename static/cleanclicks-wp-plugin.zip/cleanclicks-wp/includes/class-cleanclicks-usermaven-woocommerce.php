<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class CleanClicks_Usermaven_WooCommerce {

	private static $api_key = '';

	private static $server_token = '';

	const API_ENDPOINT = 'https://events.usermaven.com/api/v1/s2s/event';

	public static function init( $api_key, $server_token ) {
		self::$api_key      = $api_key;
		self::$server_token = $server_token;

		add_action( 'woocommerce_order_status_completed',  array( __CLASS__, 'track_order_completed' ) );
		add_action( 'woocommerce_order_status_processing', array( __CLASS__, 'track_order_processing' ) );
		add_action( 'woocommerce_order_status_pending',    array( __CLASS__, 'track_order_pending' ) );
		add_action( 'woocommerce_order_status_on-hold',    array( __CLASS__, 'track_order_on_hold' ) );
		add_action( 'woocommerce_order_status_failed',     array( __CLASS__, 'track_order_failed' ) );
		add_action( 'woocommerce_order_status_cancelled',  array( __CLASS__, 'track_order_cancelled' ) );
		add_action( 'woocommerce_order_status_refunded',   array( __CLASS__, 'track_order_refunded' ) );
		add_action( 'woocommerce_new_order',               array( __CLASS__, 'track_order_submitted' ) );

		add_action( 'woocommerce_add_to_cart',             array( __CLASS__, 'track_add_to_cart' ), 10, 6 );
		add_action( 'woocommerce_cart_item_removed',       array( __CLASS__, 'track_remove_from_cart' ), 10, 2 );

		add_action( 'template_redirect',                   array( __CLASS__, 'track_product_view' ) );
		add_action( 'wp',                                  array( __CLASS__, 'track_checkout_init' ) );

		add_action( 'woocommerce_created_customer',        array( __CLASS__, 'track_customer_created' ), 10, 3 );

		add_action( 'cleanclicks_usermaven_backfill_batch', array( __CLASS__, 'run_backfill_batch' ) );

		self::maybe_schedule_backfill();
	}

	private static function send_event( $event_type, $event_attributes, $user = array(), $context = array(), $blocking = false, $timestamp_ms = 0 ) {
		$payload = array(
			'api_key'          => self::$api_key,
			'event_type'       => $event_type,
			'_timestamp'       => (string) ( $timestamp_ms > 0 ? $timestamp_ms : (int) ( microtime( true ) * 1000 ) ),
			'src'              => 'ecommerce',
			'event_attributes' => $event_attributes,
			'user'             => $user,
			'doc_host'         => isset( $context['doc_host'] ) ? $context['doc_host'] : self::get_client_domain(),
			'url'              => isset( $context['url'] ) ? $context['url'] : '',
			'page_title'       => isset( $context['page_title'] ) ? $context['page_title'] : '',
			'doc_path'         => isset( $context['doc_path'] ) ? $context['doc_path'] : '',

			'user_language'    => get_locale() ? substr( get_locale(), 0, 5 ) : 'en',
			'doc_encoding'     => 'utf-8',
		);

		$token = rawurlencode( self::$api_key . '.' . self::$server_token );
		$url   = self::API_ENDPOINT . '?token=' . $token;

		$args = array(
			'timeout'    => 5,
			'blocking'   => $blocking,
			'sslverify'  => true,
			'headers'    => array( 'Content-Type' => 'application/json' ),
			'body'       => wp_json_encode( $payload ),
			'user-agent' => 'CleanClicks-WP/' . CLEANCLICKS_VERSION,
		);

		$response = wp_remote_post( $url, $args );

		if ( $blocking ) {
			if ( is_wp_error( $response ) ) {
				error_log( '[CleanClicks] Usermaven S2S error for ' . $event_type . ': ' . $response->get_error_message() );
				return array( 'ok' => false, 'error' => $response->get_error_message() );
			}
			$code = wp_remote_retrieve_response_code( $response );
			if ( $code < 200 || $code >= 300 ) {
				error_log( '[CleanClicks] Usermaven S2S HTTP ' . $code . ' for ' . $event_type . ': ' . wp_remote_retrieve_body( $response ) );
				return array( 'ok' => false, 'status' => $code );
			}
			return array( 'ok' => true, 'status' => $code );
		}

		return null;
	}

	private static function get_client_domain() {
		$settings = get_option( CLEANCLICKS_OPTION_KEY, array() );
		if ( ! empty( $settings['client_domain'] ) ) {
			return $settings['client_domain'];
		}
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $host ? preg_replace( '/^www\./', '', $host ) : '';
	}

	private static function get_client_ip() {
		if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ips = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
			return trim( $ips[0] );
		}
		return isset( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : '';
	}

	private static function get_anonymous_id() {
		if ( empty( $_COOKIE ) ) {
			return '';
		}
		foreach ( $_COOKIE as $name => $value ) {
			if ( strpos( $name, '__eventn_id' ) === 0 || strpos( $name, '_eventn_id' ) === 0 || strpos( $name, 'usermaven_id' ) === 0 ) {
				if ( strpos( $name, '_usr' ) !== false ) {
					continue;
				}
				return sanitize_text_field( $value );
			}
		}
		return '';
	}

	private static function is_bot_request() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
		if ( empty( $ua ) ) {
			return true;
		}
		return (bool) preg_match(
			'/bot|crawl|spider|slurp|baidu|yandex|duckduck|facebookexternalhit|twitterbot|linkedinbot|semrush|ahrefs|mj12bot|dotbot|rogerbot|screaming|pingdom|uptimerobot|gtmetrix/i',
			$ua
		);
	}

	private static function is_order_tracked( $order, $event_name ) {
		return $order->get_meta( '_cc_um_' . $event_name ) === 'yes';
	}

	private static function mark_order_tracked( $order, $event_name ) {
		$order->update_meta_data( '_cc_um_' . $event_name, 'yes' );
		$order->save();
	}

	private static function is_returning_customer( $order ) {
		$cached = $order->get_meta( '_cc_um_returning' );
		if ( $cached !== '' ) {
			return $cached === 'yes';
		}
		$customer_id = $order->get_customer_id();
		if ( ! $customer_id ) {
			$order->update_meta_data( '_cc_um_returning', 'no' );
			$order->save();
			return false;
		}
		$orders = wc_get_orders( array(
			'customer_id' => $customer_id,
			'status'      => array( 'completed', 'processing' ),
			'limit'       => 2,
		) );
		$is_returning = count( $orders ) > 1;
		$order->update_meta_data( '_cc_um_returning', $is_returning ? 'yes' : 'no' );
		$order->save();
		return $is_returning;
	}

	private static function get_location_details( $order ) {
		$countries = WC()->countries;
		$billing_country_code  = $order->get_billing_country();
		$billing_state_code    = $order->get_billing_state();
		$shipping_country_code = $order->get_shipping_country() ?: $billing_country_code;
		$shipping_state_code   = $order->get_shipping_state() ?: $billing_state_code;

		$all_countries   = $countries->get_countries();
		$billing_states  = $countries->get_states( $billing_country_code );
		$shipping_states = $countries->get_states( $shipping_country_code );

		return array(
			'billing_country_code'  => $billing_country_code,
			'billing_country_name'  => isset( $all_countries[ $billing_country_code ] ) ? $all_countries[ $billing_country_code ] : $billing_country_code,
			'billing_state_code'    => $billing_state_code,
			'billing_state_name'    => ( is_array( $billing_states ) && isset( $billing_states[ $billing_state_code ] ) ) ? $billing_states[ $billing_state_code ] : $billing_state_code,
			'shipping_country_code' => $shipping_country_code,
			'shipping_country_name' => isset( $all_countries[ $shipping_country_code ] ) ? $all_countries[ $shipping_country_code ] : $shipping_country_code,
			'shipping_state_code'   => $shipping_state_code,
			'shipping_state_name'   => ( is_array( $shipping_states ) && isset( $shipping_states[ $shipping_state_code ] ) ) ? $shipping_states[ $shipping_state_code ] : $shipping_state_code,
		);
	}

	private static function build_user( $order = null ) {
		$user = array();
		$anon_id = self::get_anonymous_id();
		if ( $anon_id ) {
			$user['anonymous_id'] = $anon_id;
		}

		if ( $order ) {
			$customer_id = $order->get_customer_id();
			if ( $customer_id ) {
				$user['id'] = (string) $customer_id;
				$wp_user    = get_userdata( $customer_id );
				$user['custom'] = array( 'role' => ( $wp_user && ! empty( $wp_user->roles ) ) ? $wp_user->roles[0] : 'customer' );
			} else {
				$user['id'] = 'guest_' . $order->get_id();
				$user['custom'] = array( 'role' => '' );
			}

			$email = $order->get_billing_email();
			if ( $email ) {
				$user['email'] = hash( 'sha256', strtolower( trim( $email ) ) ) . '@hashed.cleanclicks';
			}
		} elseif ( is_user_logged_in() ) {
			$wp_user = wp_get_current_user();
			$user['id'] = (string) $wp_user->ID;
			$user['custom'] = array( 'role' => ! empty( $wp_user->roles ) ? $wp_user->roles[0] : '' );
		}
		return $user;
	}

	private static function build_context() {

		return array(
			'doc_host'   => self::get_client_domain(),
			'url'        => isset( $_SERVER['HTTP_REFERER'] ) ? $_SERVER['HTTP_REFERER'] : ( isset( $_SERVER['REQUEST_URI'] ) ? home_url( $_SERVER['REQUEST_URI'] ) : '' ),
			'page_title' => wp_get_document_title(),
			'doc_path'   => isset( $_SERVER['REQUEST_URI'] ) ? $_SERVER['REQUEST_URI'] : '',
		);
	}

	private static function get_common_order_attributes( $order, $location_details ) {
		return array(

			'order_id'           => (int) $order->get_id(),
			'order_currency'     => (string) $order->get_currency(),
			'created_via'        => (string) $order->get_created_via(),
			'order_number'       => (string) $order->get_order_number(),
			'order_status'       => (string) $order->get_status(),

			'total'            => (float) $order->get_total(),
			'subtotal'         => (float) $order->get_subtotal(),
			'tax_total'        => (float) $order->get_total_tax(),
			'shipping_total'   => (float) $order->get_shipping_total(),
			'discount_total'   => (float) $order->get_total_discount(),
			'cart_tax'         => (float) $order->get_cart_tax(),
			'shipping_tax'     => (float) $order->get_shipping_tax(),
			'discount_tax'     => (float) $order->get_discount_tax(),
			'prices_include_tax' => (bool) $order->get_prices_include_tax(),

			'payment_method'       => (string) $order->get_payment_method(),
			'payment_method_title' => (string) $order->get_payment_method_title(),
			'date_paid'            => $order->get_date_paid() ? (string) $order->get_date_paid()->format( 'Y-m-d H:i:s' ) : null,

			'customer_type'          => $order->get_customer_id() ? 'registered' : 'guest',
			'is_registered_customer' => (bool) $order->get_customer_id(),

			'billing_state_code'   => (string) $location_details['billing_state_code'],
			'billing_country'      => (string) $location_details['billing_country_name'],
			'billing_country_code' => (string) $location_details['billing_country_code'],
			'shipping_state_code'  => (string) $location_details['shipping_state_code'],
			'shipping_country'     => (string) $location_details['shipping_country_name'],
			'shipping_country_code' => (string) $location_details['shipping_country_code'],
			'shipping_same_as_billing' => (bool) empty( $order->get_shipping_country() ),
		);
	}

	private static function get_formatted_order_items( $order ) {
		$items = array();
		foreach ( $order->get_items() as $item ) {
			$product = $item->get_product();
			if ( ! $product ) {
				continue;
			}
			$categories = array();
			$parent_id  = $product->get_parent_id() ?: $product->get_id();
			$terms      = get_the_terms( $parent_id, 'product_cat' );
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$categories[] = $term->name;
				}
			}
			$variation_id    = 0;
			$variation_attrs = array();
			if ( $product->is_type( 'variation' ) ) {
				$variation_id    = $product->get_id();
				$variation_attrs = $product->get_variation_attributes();
			}
			$items[] = array(
				'product_id'           => (int) $parent_id,
				'product_name'         => (string) $product->get_name(),
				'quantity'             => (int) $item->get_quantity(),
				'price'                => (float) $order->get_item_total( $item, false, true ),
				'subtotal'             => (float) $item->get_subtotal(),
				'total'                => (float) $item->get_total(),
				'sku'                  => (string) $product->get_sku(),
				'categories'           => $categories,
				'variation_id'         => $variation_id ?: null,
				'variation_attributes' => $variation_attrs,
				'tax'                  => (float) $item->get_total_tax(),
			);
		}
		return $items;
	}

	private static function get_shipping_methods( $order ) {
		$methods = array();
		foreach ( $order->get_shipping_methods() as $method ) {
			$methods[] = array(
				'method_id'    => (string) $method->get_method_id(),
				'method_title' => (string) $method->get_method_title(),
				'total'        => (float) $method->get_total(),
				'total_tax'    => (float) $method->get_total_tax(),
			);
		}
		return $methods;
	}

	private static function get_device_type() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : '';
		if ( preg_match( '/Mobile|Android|iPhone|iPad/i', $ua ) ) {
			return preg_match( '/iPad|Tablet/i', $ua ) ? 'tablet' : 'mobile';
		}
		return 'desktop';
	}

	public static function track_order_completed( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_completed' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$items        = self::get_formatted_order_items( $order );
		$is_returning = self::is_returning_customer( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'is_returning_customer' => $is_returning,
				'is_first_order'        => ! $is_returning,
				'items_count'           => (int) $order->get_item_count(),
				'items'                 => $items,
				'shipping_methods'      => self::get_shipping_methods( $order ),
				'coupons_used'          => array_map( 'strval', $order->get_coupon_codes() ),
				'device_type'           => self::get_device_type(),
				'completion_date'       => $order->get_date_completed() ? $order->get_date_completed()->format( 'Y-m-d H:i:s' ) : current_time( 'mysql' ),
				'timestamp'             => (string) current_time( 'mysql' ),
			)
		);
		if ( $order->get_date_created() && $order->get_date_completed() ) {
			$attrs['order_processing_time'] = round(
				( $order->get_date_completed()->getTimestamp() - $order->get_date_created()->getTimestamp() ) / 3600, 2
			);
		}
		$result = self::send_event( 'order_completed', $attrs, self::build_user( $order ), self::build_context(), true );
		if ( $result && ! empty( $result['ok'] ) ) {
			self::mark_order_tracked( $order, 'order_completed' );
		}
	}

	public static function track_order_submitted( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_submitted' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$items        = self::get_formatted_order_items( $order );
		$is_returning = self::is_returning_customer( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'is_returning_customer' => $is_returning,
				'is_first_order'        => ! $is_returning,
				'items_count'           => (int) $order->get_item_count(),
				'items'                 => $items,
				'shipping_methods'      => self::get_shipping_methods( $order ),
				'coupons_used'          => array_map( 'strval', $order->get_coupon_codes() ),
				'device_type'           => self::get_device_type(),
				'timestamp'             => (string) current_time( 'mysql' ),
			)
		);
		$result = self::send_event( 'order_submitted', $attrs, self::build_user( $order ), self::build_context(), true );
		if ( $result && ! empty( $result['ok'] ) ) {
			self::mark_order_tracked( $order, 'order_submitted' );
		}
	}

	public static function track_order_processing( $order_id ) {
		self::track_simple_order_event( $order_id, 'order_in_processing' );
	}

	public static function track_order_pending( $order_id ) {
		self::track_simple_order_event( $order_id, 'order_pending' );
	}

	public static function track_order_on_hold( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_on_hold' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'hold_reason' => (string) $order->get_customer_note(),
				'hold_date'   => (string) current_time( 'mysql' ),
				'items_count' => (int) $order->get_item_count(),
				'items'       => self::get_formatted_order_items( $order ),
				'device_type' => self::get_device_type(),
				'timestamp'   => (string) current_time( 'mysql' ),
			)
		);
		self::send_event( 'order_on_hold', $attrs, self::build_user( $order ), self::build_context() );
		self::mark_order_tracked( $order, 'order_on_hold' );
	}

	public static function track_order_failed( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_failed' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'gateway_response' => (string) $order->get_meta( '_transaction_message' ),
				'failure_codes'    => (string) $order->get_transaction_id(),
				'items_count'      => (int) $order->get_item_count(),
				'items'            => self::get_formatted_order_items( $order ),
				'device_type'      => self::get_device_type(),
				'timestamp'        => (string) current_time( 'mysql' ),
			)
		);
		self::send_event( 'order_failed', $attrs, self::build_user( $order ), self::build_context() );
		self::mark_order_tracked( $order, 'order_failed' );
	}

	public static function track_order_cancelled( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_cancelled' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'cancellation_reason' => (string) $order->get_customer_note(),
				'cancelled_by'        => ( $order->get_customer_id() || $order->get_meta( '_cancelled_by_customer' ) ) ? 'customer' : 'admin',
				'cancellation_date'   => (string) current_time( 'mysql' ),
				'items_count'         => (int) $order->get_item_count(),
				'items'               => self::get_formatted_order_items( $order ),
				'device_type'         => self::get_device_type(),
				'timestamp'           => (string) current_time( 'mysql' ),
			)
		);
		self::send_event( 'order_cancelled', $attrs, self::build_user( $order ), self::build_context() );
		self::mark_order_tracked( $order, 'order_cancelled' );
	}

	public static function track_order_refunded( $order_id ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, 'order_refunded' ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$refunds       = $order->get_refunds();
		$latest_refund = ! empty( $refunds ) ? $refunds[0] : null;
		$refund_amount = $latest_refund ? abs( (float) $latest_refund->get_total() ) : (float) $order->get_total_refunded();
		$is_partial    = $refund_amount < (float) $order->get_total();

		$refunded_items = array();
		if ( $latest_refund ) {
			foreach ( $latest_refund->get_items() as $item ) {
				$product = $item->get_product();
				$refunded_items[] = array(
					'product_id'   => $product ? (int) $product->get_id() : 0,
					'product_name' => (string) $item->get_name(),
					'quantity'     => abs( (int) $item->get_quantity() ),
					'refund_total' => abs( (float) $item->get_total() ),
					'refund_tax'   => abs( (float) $item->get_total_tax() ),
				);
			}
		}

		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'refund_id'             => $latest_refund ? (int) $latest_refund->get_id() : null,
				'refund_amount'         => $refund_amount,
				'refund_reason'         => $latest_refund ? (string) $latest_refund->get_reason() : '',
				'refund_date'           => (string) current_time( 'mysql' ),
				'is_partial_refund'     => $is_partial,
				'original_order_total'  => (float) $order->get_total(),
				'remaining_order_total' => (float) $order->get_total() - (float) $order->get_total_refunded(),
				'refunded_items_count'  => count( $refunded_items ),
				'refunded_items'        => $refunded_items,
				'items_count'           => (int) $order->get_item_count(),
				'items'                 => self::get_formatted_order_items( $order ),
				'device_type'           => self::get_device_type(),
				'timestamp'             => (string) current_time( 'mysql' ),
			)
		);
		$result = self::send_event( 'order_refunded', $attrs, self::build_user( $order ), self::build_context(), true );
		if ( $result && ! empty( $result['ok'] ) ) {
			self::mark_order_tracked( $order, 'order_refunded' );
		}
	}

	private static function track_simple_order_event( $order_id, $event_name ) {
		$order = wc_get_order( $order_id );
		if ( ! $order || self::is_order_tracked( $order, $event_name ) ) {
			return;
		}
		$location = self::get_location_details( $order );
		$attrs = array_merge(
			self::get_common_order_attributes( $order, $location ),
			array(
				'items_count' => (int) $order->get_item_count(),
				'items'       => self::get_formatted_order_items( $order ),
				'device_type' => self::get_device_type(),
				'timestamp'   => (string) current_time( 'mysql' ),
			)
		);
		self::send_event( $event_name, $attrs, self::build_user( $order ), self::build_context() );
		self::mark_order_tracked( $order, $event_name );
	}

	public static function track_product_view() {
		if ( ! is_product() || self::is_bot_request() ) {
			return;
		}
		global $product;
		if ( ! $product || ! is_a( $product, 'WC_Product' ) ) {
			return;
		}
		$categories = array();
		$terms = get_the_terms( $product->get_id(), 'product_cat' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = $term->name;
			}
		}
		$attrs = array(
			'product_id'   => (int) $product->get_id(),
			'product_name' => (string) $product->get_name(),
			'price'        => (float) $product->get_price(),
			'currency'     => (string) get_woocommerce_currency(),
			'type'         => (string) $product->get_type(),
			'sku'          => (string) $product->get_sku(),
			'categories'   => $categories,
			'stock_status' => (string) $product->get_stock_status(),
			'items'        => array( array(
				'product_id'   => (int) $product->get_id(),
				'product_name' => (string) $product->get_name(),
				'price'        => (float) $product->get_price(),
				'sku'          => (string) $product->get_sku(),
				'categories'   => $categories,
			) ),
		);
		self::send_event( 'viewed_product', $attrs, self::build_user(), self::build_context() );
	}

	public static function track_add_to_cart( $cart_item_key, $product_id, $quantity, $variation_id, $variation, $cart_item_data ) {
		$product = wc_get_product( $variation_id ?: $product_id );
		if ( ! $product ) {
			return;
		}
		$categories = array();
		$parent_id  = $product->get_parent_id() ?: $product->get_id();
		$terms      = get_the_terms( $parent_id, 'product_cat' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = $term->name;
			}
		}
		$cart = WC()->cart;
		$attrs = array(
			'product_id'           => (int) $parent_id,
			'product_name'         => (string) $product->get_name(),
			'product_sku'          => (string) $product->get_sku(),
			'product_type'         => (string) $product->get_type(),
			'categories'           => $categories,
			'quantity'             => (int) $quantity,
			'unit_price'           => (float) $product->get_price(),
			'currency'             => (string) get_woocommerce_currency(),
			'variation_id'         => $variation_id ?: null,
			'variation_attributes' => is_array( $variation ) ? $variation : array(),
			'cart_total'           => $cart ? (float) $cart->get_total( 'edit' ) : 0,
			'cart_subtotal'        => $cart ? (float) $cart->get_subtotal() : 0,
			'cart_items_count'     => $cart ? (int) $cart->get_cart_contents_count() : 0,
			'applied_coupons'      => $cart ? $cart->get_applied_coupons() : array(),
			'device_type'          => self::get_device_type(),
			'items'                => array( array(
				'product_id'   => (int) $parent_id,
				'product_name' => (string) $product->get_name(),
				'product_sku'  => (string) $product->get_sku(),
				'quantity'     => (int) $quantity,
				'unit_price'   => (float) $product->get_price(),
				'categories'   => $categories,
			) ),
		);
		self::send_event( 'added_to_cart', $attrs, self::build_user(), self::build_context() );
	}

	public static function track_remove_from_cart( $cart_item_key, $cart ) {
		$item = isset( $cart->removed_cart_contents[ $cart_item_key ] ) ? $cart->removed_cart_contents[ $cart_item_key ] : null;
		if ( ! $item ) {
			return;
		}
		$product_id = isset( $item['variation_id'] ) && $item['variation_id'] ? $item['variation_id'] : $item['product_id'];
		$product    = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		$parent_id  = $product->get_parent_id() ?: $product->get_id();
		$categories = array();
		$terms      = get_the_terms( $parent_id, 'product_cat' );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $term ) {
				$categories[] = $term->name;
			}
		}
		$attrs = array(
			'product_id'       => (int) $parent_id,
			'product_name'     => (string) $product->get_name(),
			'product_sku'      => (string) $product->get_sku(),
			'quantity_removed' => isset( $item['quantity'] ) ? (int) $item['quantity'] : 1,
			'price_per_unit'   => (float) $product->get_price(),
			'currency'         => (string) get_woocommerce_currency(),
			'categories'       => $categories,
			'cart_total'       => (float) $cart->get_total( 'edit' ),
			'cart_subtotal'    => (float) $cart->get_subtotal(),
			'remaining_items'  => (int) $cart->get_cart_contents_count(),
			'applied_coupons'  => $cart->get_applied_coupons(),
			'device_type'      => self::get_device_type(),
			'items'            => array( array(
				'product_id'   => (int) $parent_id,
				'product_name' => (string) $product->get_name(),
				'product_sku'  => (string) $product->get_sku(),
				'quantity'     => isset( $item['quantity'] ) ? (int) $item['quantity'] : 1,
				'unit_price'   => (float) $product->get_price(),
				'categories'   => $categories,
			) ),
		);
		self::send_event( 'removed_from_cart', $attrs, self::build_user(), self::build_context() );
	}

	public static function track_checkout_init() {
		if ( ! is_checkout() || is_wc_endpoint_url( 'order-received' ) || self::is_bot_request() ) {
			return;
		}
		if ( function_exists( 'WC' ) && WC()->session ) {
			$cart_hash = WC()->cart ? md5( wp_json_encode( WC()->cart->get_cart() ) ) : '';
			$last_hash = WC()->session->get( 'cleanclicks_tracked_cart_hash' );
			$last_time = (int) WC()->session->get( 'cleanclicks_last_checkout_track_time' );
			if ( $cart_hash === $last_hash && ( time() - $last_time ) < 300 ) {
				return;
			}
			WC()->session->set( 'cleanclicks_tracked_cart_hash', $cart_hash );
			WC()->session->set( 'cleanclicks_last_checkout_track_time', time() );
		}
		$cart = WC()->cart;
		if ( ! $cart ) {
			return;
		}
		$items = array();
		foreach ( $cart->get_cart() as $cart_item ) {
			$product = $cart_item['data'];
			if ( ! $product ) {
				continue;
			}
			$parent_id  = $product->get_parent_id() ?: $product->get_id();
			$categories = array();
			$terms      = get_the_terms( $parent_id, 'product_cat' );
			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$categories[] = $term->name;
				}
			}
			$items[] = array(
				'product_id'   => (int) $parent_id,
				'product_name' => (string) $product->get_name(),
				'product_sku'  => (string) $product->get_sku(),
				'quantity'     => (int) $cart_item['quantity'],
				'unit_price'   => (float) $product->get_price(),
				'line_total'   => (float) $cart_item['line_total'],
				'categories'   => $categories,
				'variation_id' => isset( $cart_item['variation_id'] ) && $cart_item['variation_id'] ? (int) $cart_item['variation_id'] : null,
			);
		}
		$customer = WC()->customer;
		$attrs = array(
			'total'                 => (float) $cart->get_total( 'edit' ),
			'subtotal'              => (float) $cart->get_subtotal(),
			'cart_tax'              => (float) $cart->get_cart_contents_tax(),
			'shipping_total'        => (float) $cart->get_shipping_total(),
			'discount_total'        => (float) $cart->get_discount_total(),
			'currency'              => (string) get_woocommerce_currency(),
			'items_count'           => (int) $cart->get_cart_contents_count(),
			'unique_items'          => count( $cart->get_cart() ),
			'items'                 => $items,
			'applied_coupons'       => $cart->get_applied_coupons(),
			'is_logged_in'          => is_user_logged_in(),
			'customer_id'           => is_user_logged_in() ? get_current_user_id() : null,
			'billing_country_code'  => $customer ? (string) $customer->get_billing_country() : '',
			'shipping_country_code' => $customer ? (string) $customer->get_shipping_country() : '',
			'device_type'           => self::get_device_type(),
			'timestamp'             => (string) current_time( 'mysql' ),
		);
		self::send_event( 'initiated_checkout', $attrs, self::build_user(), self::build_context() );
	}

	public static function track_customer_created( $customer_id, $new_customer_data, $password_generated ) {
		$wp_user = get_userdata( $customer_id );
		if ( ! $wp_user ) {
			return;
		}
		$attrs = array(
			'customer_id' => (int) $customer_id,
			'role'        => ! empty( $wp_user->roles ) ? $wp_user->roles[0] : 'customer',
			'timestamp'   => (string) current_time( 'mysql' ),
		);
		$user = array(
			'id'         => (string) $customer_id,
			'created_at' => $wp_user->user_registered,
		);
		$anon_id = self::get_anonymous_id();
		if ( $anon_id ) {
			$user['anonymous_id'] = $anon_id;
		}
		self::send_event( 'customer_created', $attrs, $user, self::build_context() );
	}

	private static function maybe_schedule_backfill() {

		if ( get_option( 'cleanclicks_usermaven_backfill_v3_complete', '' ) === '1' ) {
			return;
		}
		if ( wp_next_scheduled( 'cleanclicks_usermaven_backfill_batch' ) ) {
			return;
		}
		$total = self::count_backfill_orders();
		if ( $total <= 0 ) {
			update_option( 'cleanclicks_usermaven_backfill_v3_complete', '1' );
			return;
		}
		update_option( 'cleanclicks_usermaven_backfill_v3_total', $total );
		update_option( 'cleanclicks_usermaven_backfill_v3_offset', 0 );
		wp_schedule_single_event( time() + 5, 'cleanclicks_usermaven_backfill_batch' );
	}

	private static function count_backfill_orders() {
		$date_after = gmdate( 'Y-m-d', strtotime( '-12 months' ) );
		$orders = wc_get_orders( array(
			'status'     => array( 'completed', 'processing' ),
			'date_after' => $date_after,
			'limit'      => -1,
			'return'     => 'ids',
		) );
		return count( $orders );
	}

	public static function run_backfill_batch() {
		$offset     = (int) get_option( 'cleanclicks_usermaven_backfill_v3_offset', 0 );
		$total      = (int) get_option( 'cleanclicks_usermaven_backfill_v3_total', 0 );
		$batch_size = 25;
		$date_after = gmdate( 'Y-m-d', strtotime( '-12 months' ) );

		$orders = wc_get_orders( array(
			'status'     => array( 'completed', 'processing' ),
			'date_after' => $date_after,
			'orderby'    => 'date',
			'order'      => 'ASC',
			'limit'      => $batch_size,
			'offset'     => $offset,
		) );

		if ( empty( $orders ) ) {
			update_option( 'cleanclicks_usermaven_backfill_v3_complete', '1' );
			update_option( 'cleanclicks_usermaven_backfill_v3_offset', $total );
			return;
		}

		foreach ( $orders as $order ) {
			if ( self::is_order_tracked( $order, 'backfill_v3' ) ) {
				continue;
			}
			$location = self::get_location_details( $order );
			$items    = self::get_formatted_order_items( $order );
			$is_returning = self::is_returning_customer( $order );
			$attrs = array_merge(
				self::get_common_order_attributes( $order, $location ),
				array(
					'is_returning_customer' => $is_returning,
					'is_first_order'        => ! $is_returning,
					'items_count'           => (int) $order->get_item_count(),
					'items'                 => $items,
					'shipping_methods'      => self::get_shipping_methods( $order ),
					'coupons_used'          => array_map( 'strval', $order->get_coupon_codes() ),
					'device_type'           => 'desktop',
					'timestamp'             => $order->get_date_completed()
						? $order->get_date_completed()->format( 'Y-m-d H:i:s' )
						: $order->get_date_created()->format( 'Y-m-d H:i:s' ),
				)
			);
			$ts_ms = $order->get_date_completed()
				? $order->get_date_completed()->getTimestamp() * 1000
				: $order->get_date_created()->getTimestamp() * 1000;

			$user = self::build_user( $order );

			$context = array(
				'doc_host' => self::get_client_domain(),
				'url'      => home_url( '/checkout/order-received/' . $order->get_id() . '/' ),
				'page_title' => 'Order Received',
				'doc_path'   => '/checkout/order-received/' . $order->get_id() . '/',
			);

			$result = self::send_event( 'order_in_processing', $attrs, $user, $context, true, $ts_ms );
			if ( $result && isset( $result['status'] ) && $result['status'] === 429 ) {
				sleep( 5 );
				break;
			}
			usleep( 200000 );

			$result2 = self::send_event( 'order_completed', $attrs, $user, $context, true, $ts_ms );
			if ( $result2 && isset( $result2['status'] ) && $result2['status'] === 429 ) {
				sleep( 5 );
				break;
			}
			usleep( 200000 );

			if ( ( $result && ! empty( $result['ok'] ) ) || ( $result2 && ! empty( $result2['ok'] ) ) ) {
				self::mark_order_tracked( $order, 'backfill_v3' );
			}
		}

		$new_offset = $offset + $batch_size;
		update_option( 'cleanclicks_usermaven_backfill_v3_offset', $new_offset );

		if ( $new_offset < $total ) {
			wp_schedule_single_event( time() + 10, 'cleanclicks_usermaven_backfill_batch' );
		} else {
			update_option( 'cleanclicks_usermaven_backfill_v3_complete', '1' );
		}
	}

}
