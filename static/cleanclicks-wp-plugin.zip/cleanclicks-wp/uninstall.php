<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'cleanclicks_settings' );
delete_option( 'cleanclicks_smart_defaults_applied' );
delete_transient( 'cleanclicks_remote_config' );

$users = get_users( array( 'fields' => 'ID' ) );
foreach ( $users as $uid ) {
	delete_user_meta( $uid, 'cleanclicks_dismiss_notice' );
}
